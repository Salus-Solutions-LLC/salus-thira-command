"""Server-derived SalCAPA PROVE assurance register and trace-gap model.

PROVE is a cross-cutting assurance view over persisted authoritative records.  It
does not create facts, infer causality, release records, or replace component and
human lifecycle authority.
"""
from __future__ import annotations

from fastapi import HTTPException, Request


STAGE_DEFINITIONS = (
    ("qualified_intelligence", "Qualified intelligence", "SalINTEL™", "See"),
    ("risk_priority", "Risk and priority", "SalTHIRA™", "Decide"),
    ("decision", "Authorized decision", "Authorized people", "Decide"),
    ("authorized_action", "Authorized action", "SalCAPA™ / SalOPS™", "Coordinate / Act"),
    ("execution", "Execution", "SalOPS™", "Act"),
    ("evidence", "Evidence and provenance", "SalCAPA™ assurance", "Prove"),
    ("result_validation", "Result and validation", "SalCAPA™ assurance", "Prove"),
    ("reassessment", "Reassessment and learning", "SalCAPA-wide", "See / Decide"),
)


def register_salcapa_assurance(app, core: dict) -> None:
    db = core["db"]
    require = core["require"]
    tenant_id = core["tenant_id"]
    accessible_assessment_ids = core["accessible_assessment_ids"]
    protected_member = core["protected_member_request"]
    require_sensitivity = core["require_sensitivity"]

    def rows(conn, sql: str, params=()):
        return [dict(item) for item in conn.execute(sql, params)]

    def selected_assessments(conn, request: Request, assessment_id: int | None):
        allowed = set(accessible_assessment_ids(request))
        if assessment_id is not None:
            candidate = conn.execute(
                "SELECT * FROM assessments WHERE id=?", (assessment_id,)
            ).fetchone()
            if not candidate:
                raise HTTPException(404, "Assessment not found")
            if int(candidate["tenant_id"]) != tenant_id(request) or assessment_id not in allowed:
                raise HTTPException(403, "Assessment access denied")
            require_sensitivity(request, candidate["classification"])
            return [dict(candidate)]
        result = []
        for item in conn.execute(
            "SELECT * FROM assessments WHERE tenant_id=? ORDER BY id", (tenant_id(request),)
        ):
            if int(item["id"]) in allowed:
                try:
                    require_sensitivity(request, item["classification"])
                except HTTPException:
                    continue
                result.append(dict(item))
        return result

    def node(kind: str, item: dict, label_field: str, status_field: str = "status"):
        return {
            "key": f"{kind}:{item['id']}", "record_type": kind,
            "record_id": int(item["id"]), "label": item.get(label_field) or f"{kind} #{item['id']}",
            "status": item.get(status_field, ""),
        }

    def build_assurance(conn, request: Request, assessment: dict):
        aid, tid = int(assessment["id"]), tenant_id(request)
        is_member = protected_member(request)
        intelligence = rows(conn,
            "SELECT id,title,status,credibility,validation_status,qualified_at FROM intel_findings "
            "WHERE tenant_id=? AND assessment_id=? AND status IN ('Qualified','Sent to SalTHIRA') ORDER BY id",
            (tid, aid))
        threats = rows(conn,
            "SELECT id,name,status,inclusion_status FROM threats WHERE assessment_id=? ORDER BY id", (aid,))
        scenarios = rows(conn,
            "SELECT id,threat_id,title,evidence_confidence FROM scenarios WHERE assessment_id=? ORDER BY id", (aid,))
        capabilities = rows(conn,
            "SELECT id,scenario_id,name,confidence,current_performance,required_standard,last_validated "
            "FROM capabilities WHERE assessment_id=? ORDER BY id", (aid,))
        gaps = rows(conn,
            "SELECT id,capability_id,description,severity,status FROM gaps WHERE assessment_id=? ORDER BY id", (aid,))
        improvements = rows(conn,
            "SELECT id,gap_id,title,status,validation_status,validation_evidence_id,validation_outcome,"
            "validated_at FROM improvements WHERE assessment_id=? ORDER BY id", (aid,))
        decisions = rows(conn,
            "SELECT id,improvement_id,decision_type,authority,review_lifecycle_status,created_at "
            "FROM decisions WHERE assessment_id=? ORDER BY id", (aid,))
        requests = rows(conn,
            "SELECT id,source_type,source_id,title,status,result_summary,completed_at FROM ops_requests "
            "WHERE tenant_id=? AND assessment_id=? ORDER BY id", (tid, aid))
        engagements = rows(conn,
            "SELECT id,ops_request_id,title,status FROM ops_engagements WHERE tenant_id=? AND assessment_id=? ORDER BY id",
            (tid, aid))
        tasks = rows(conn,
            "SELECT id,engagement_id,title,status,result_summary,completed_at FROM ops_tasks "
            "WHERE tenant_id=? AND assessment_id=? ORDER BY id", (tid, aid))
        evidence = []
        for item in conn.execute(
            "SELECT id,capability_id,scenario_id,title,verification_status,lifecycle_status,sensitivity,"
            "evidence_date,updated_at FROM evidence WHERE assessment_id=? ORDER BY id", (aid,)
        ):
            try:
                require_sensitivity(request, item["sensitivity"])
            except HTTPException:
                continue
            value = dict(item)
            if not is_member or (
                value["verification_status"] == "Verified" and value["lifecycle_status"] == "Current"
            ):
                evidence.append(value)
        triggers = rows(conn,
            "SELECT id,affected_record_type,affected_record_id,trigger_type,severity,status,created_at "
            "FROM reassessment_triggers WHERE assessment_id=? ORDER BY id", (aid,))
        reports = rows(conn,
            "SELECT id,report_type,status,released_at FROM report_versions WHERE tenant_id=? "
            "AND assessment_id=? AND status='Released' ORDER BY id", (tid, aid))
        field_reports = rows(conn,
            "SELECT id,engagement_id,task_id,report_type,status,released_at FROM ops_field_reports "
            "WHERE tenant_id=? AND assessment_id=? AND status='Released' ORDER BY id", (tid, aid))

        nodes = []
        nodes.extend(node("intel_finding", item, "title") for item in intelligence)
        nodes.extend(node("threat", item, "name") for item in threats)
        nodes.extend(node("scenario", item, "title", "evidence_confidence") for item in scenarios)
        nodes.extend(node("capability", item, "name", "confidence") for item in capabilities)
        nodes.extend(node("gap", item, "description") for item in gaps)
        nodes.extend(node("improvement", item, "title") for item in improvements)
        nodes.extend(node("decision", item, "decision_type", "review_lifecycle_status") for item in decisions)
        nodes.extend(node("ops_request", item, "title") for item in requests)
        nodes.extend(node("ops_engagement", item, "title") for item in engagements)
        nodes.extend(node("ops_task", item, "title") for item in tasks)
        nodes.extend(node("evidence", item, "title", "verification_status") for item in evidence)
        nodes.extend(node("reassessment_trigger", item, "trigger_type") for item in triggers)

        keys = {item["key"] for item in nodes}
        edges = []
        def edge(source: str, target: str, relationship: str):
            if source in keys and target in keys:
                edges.append({"source": source, "target": target,
                              "relationship": relationship, "basis": "Persisted explicit link"})
        for item in scenarios:
            edge(f"threat:{item['threat_id']}", f"scenario:{item['id']}", "has scenario")
        for item in capabilities:
            if item["scenario_id"]:
                edge(f"scenario:{item['scenario_id']}", f"capability:{item['id']}", "requires capability")
        for item in gaps:
            edge(f"capability:{item['capability_id']}", f"gap:{item['id']}", "has capability gap")
        for item in improvements:
            edge(f"gap:{item['gap_id']}", f"improvement:{item['id']}", "addressed by")
            if item["validation_evidence_id"]:
                edge(f"evidence:{item['validation_evidence_id']}", f"improvement:{item['id']}", "validates")
        for item in decisions:
            if item["improvement_id"]:
                edge(f"improvement:{item['improvement_id']}", f"decision:{item['id']}", "governed by decision")
        for item in requests:
            if item["source_type"] and item["source_id"]:
                edge(f"{item['source_type']}:{item['source_id']}", f"ops_request:{item['id']}", "authorizes request")
        for item in engagements:
            edge(f"ops_request:{item['ops_request_id']}", f"ops_engagement:{item['id']}", "implemented through")
        for item in tasks:
            edge(f"ops_engagement:{item['engagement_id']}", f"ops_task:{item['id']}", "contains task")
        for item in evidence:
            if item["capability_id"]:
                edge(f"evidence:{item['id']}", f"capability:{item['capability_id']}", "supports capability")
            if item["scenario_id"]:
                edge(f"evidence:{item['id']}", f"scenario:{item['scenario_id']}", "supports scenario")
        for item in triggers:
            if item["affected_record_type"] and item["affected_record_id"]:
                edge(f"{item['affected_record_type']}:{item['affected_record_id']}",
                     f"reassessment_trigger:{item['id']}", "triggers reassessment")

        authorized_requests = [item for item in requests
                               if item["status"] in ("Authorized", "In Progress", "Completed")]
        completed_work = [item for item in requests + tasks if item["status"] == "Completed"]
        verified_evidence = [item for item in evidence if item["verification_status"] == "Verified"
                             and item["lifecycle_status"] == "Current"]
        validated = [item for item in improvements
                     if item["validation_status"] in ("Validated", "Partially Validated")]
        stage_counts = {
            "qualified_intelligence": len(intelligence),
            "risk_priority": len([item for item in threats if item["status"] == "Active"])
                             + len(improvements),
            "decision": len(decisions), "authorized_action": len(authorized_requests),
            "execution": len(completed_work),
            "evidence": len(verified_evidence) + len(reports) + len(field_reports),
            "result_validation": len(validated) + len([item for item in completed_work
                                                       if item.get("result_summary")]),
            "reassessment": len(triggers),
        }
        stages = [{"key": key, "label": label, "owner": owner, "function": function,
                   "record_count": stage_counts[key],
                   "state": "Evidence present" if stage_counts[key] else "Assurance gap"}
                  for key, label, owner, function in STAGE_DEFINITIONS]
        assurance_gaps = [{"gap_key": f"stage:{item['key']}", "stage": item["label"],
                           "reason": "No qualifying persisted record is available.",
                           "inferred": False}
                          for item in stages if not item["record_count"]]
        request_by_improvement = {int(item["source_id"]) for item in authorized_requests
                                  if item["source_type"] == "improvement" and item["source_id"]}
        for item in decisions:
            if item["decision_type"] in ("Approve", "Approve with Conditions") and item["improvement_id"] \
                    and int(item["improvement_id"]) not in request_by_improvement:
                assurance_gaps.append({"gap_key": f"decision:{item['id']}:action",
                    "stage": "Decision to authorized action",
                    "reason": "Approved decision has no explicitly linked authorized SalOPS request.",
                    "record_key": f"decision:{item['id']}", "inferred": False})
        for item in improvements:
            if item["status"] == "Complete" and item["validation_status"] not in (
                "Validated", "Partially Validated"
            ):
                assurance_gaps.append({"gap_key": f"improvement:{item['id']}:validation",
                    "stage": "Completion to validation",
                    "reason": "Completed improvement lacks governed validation.",
                    "record_key": f"improvement:{item['id']}", "inferred": False})
        if intelligence and not any(edge_item["source"].startswith("intel_finding:")
                                    for edge_item in edges):
            assurance_gaps.append({"gap_key": "intelligence:explicit-risk-link",
                "stage": "Qualified intelligence to risk/priority",
                "reason": "Qualified intelligence exists, but no explicit persisted downstream link is available.",
                "inferred": False})

        return {
            "assessment": {"id": aid, "name": assessment["name"],
                           "organization": assessment["organization"],
                           "status": assessment["status"], "version": assessment["version"]},
            "stages": stages, "nodes": nodes, "explicit_edges": edges,
            "assurance_gaps": assurance_gaps,
            "released_outputs": {"reports": reports, "field_reports": field_reports},
            "trace_policy": {"server_derived": True, "explicit_links_only": True,
                             "missing_links_are_gaps": True, "automatic_completion": False,
                             "automatic_disclosure": False, "automatic_authority": False},
        }

    @app.get("/api/salcapa/assurance")
    def salcapa_assurance(request: Request, assessment_id: int | None = None):
        require(request, "read")
        conn = db()
        try:
            assessments = selected_assessments(conn, request, assessment_id)
            result = [build_assurance(conn, request, item) for item in assessments]
            return {
                "workspace": "PROVE — Assurance & Results",
                "purpose": "Evidence, accountability, results, validation, learning, and improvement across SalCAPA.",
                "cross_cutting": True, "not_a_separate_product": True,
                "assessments": result,
                "links": [
                    {"label": "Evidence & provenance", "view": "evidence"},
                    {"label": "Decision record", "view": "decisions"},
                    {"label": "Action verification", "view": "implementation"},
                    {"label": "Capability validation", "view": "capabilities"},
                    {"label": "Reassessment history", "view": "reassessment"},
                    {"label": "Reports", "view": "reports"},
                    {"label": "Audit & version history", "view": "audit"},
                ],
            }
        finally:
            conn.close()
