#!/usr/bin/env python3
"""Acceptance smoke for Issue #162 SalOPS preparedness, planning, training and exercises."""
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORK = tempfile.TemporaryDirectory()
os.environ.setdefault("SALUS_DB_BACKEND", "sqlite")
os.environ.setdefault("SALUS_DB_PATH", str(Path(WORK.name) / "preparedness.db"))
os.environ.setdefault("SALUS_BACKUP_DIR", str(Path(WORK.name) / "backups"))
os.environ.setdefault("SALUS_LOCAL_STORAGE_DIR", str(Path(WORK.name) / "attachments"))
os.environ.setdefault("SALUS_AUTH_MODE", "prototype")
os.environ.setdefault("SALUS_SEED_DEMO", "1")
sys.path.insert(0, str(ROOT))

from fastapi.testclient import TestClient
import salcapa_runtime as runtime
app = runtime.core


def main():
    client = TestClient(runtime.app)
    salus = {"X-Salus-Tenant":"1","X-Salus-Role":"Assessment Director","X-Salus-User":"Preparedness Lead"}
    member = {"X-Salus-Tenant":"1","X-Salus-Role":"Client Executive","X-Salus-User":"Protected Member Executive"}
    other = {"X-Salus-Tenant":"2","X-Salus-Role":"Assessment Director","X-Salus-User":"Other Tenant"}

    catalog = client.get("/api/salops/preparedness/catalog", headers=salus)
    assert catalog.status_code == 200, catalog.text
    assert catalog.json()["lifecycle"] == ["Plan","Train","Exercise","Observe","Evaluate","Improve","Validate","Sustain"]
    assert catalog.json()["principles"]["training_completion_is_readiness_proof"] is False
    assert catalog.json()["principles"]["corrective_completion_equals_validation"] is False
    assert "Tabletop Exercise" in catalog.json()["exercise_types"]

    forged = client.post("/api/salops/preparedness/plans", headers=salus, json={
        "title":"Forged", "plan_type":"Crisis Communications", "scope_statement":"Synthetic scope",
        "status":"Approved", "tenant_id":2, "version":99})
    assert forged.status_code == 422, forged.text

    plan = client.post("/api/salops/preparedness/plans", headers=salus, json={
        "title":"SYNTHETIC Crisis Communications Plan", "plan_type":"Crisis Communications",
        "purpose":"Coordinate protective crisis communications.",
        "scope_statement":"SYNTHETIC headquarters communications team only.",
        "portfolio_scope":{"facilities":["SYNTHETIC-HQ"],"dynamic_inclusion":False},
        "mission_lenses":["Prevention","Protection","Response","Recovery"],
        "roles_responsibilities":"Primary spokesperson and alternate spokesperson roles.",
        "concept_of_operations":"Defensive emergency communications coordination.",
        "communications":"Use approved notification and public-information channels.",
        "known_unknowns":"Alternate-channel availability requires validation.",
        "commercial_treatment":"Membership Included",
        "membership_entitlement_ref":"SYNTHETIC-MEMBER-PLAN-REVIEW"})
    assert plan.status_code == 200, plan.text
    plan_id = plan.json()["id"]
    assert plan.json()["status"] == "Draft" and plan.json()["version"] == 1
    assert client.get("/api/salops/preparedness/plans", headers=member).json() == []
    for status in ("Reviewed","Approved"):
        r=client.post(f"/api/salops/preparedness/plans/{plan_id}/transition",headers=salus,json={"status":status,"reason":"SYNTHETIC governed plan authority gate."})
        assert r.status_code == 200, r.text
    shown=client.get(f"/api/salops/preparedness/plans/{plan_id}",headers=member)
    assert shown.status_code==200,shown.text
    assert "known_unknowns" not in shown.json()["plan"]
    adopted=client.post(f"/api/salops/preparedness/plans/{plan_id}/member-adoption",headers=member,json={"decision":"Adopted","reason":"SYNTHETIC executive adoption for exercise."})
    assert adopted.status_code==200 and adopted.json()["member_adoption_status"]=="Adopted"

    training=client.post("/api/salops/preparedness/training",headers=salus,json={
        "plan_id":plan_id,"title":"SYNTHETIC Spokesperson Refresher","objective":"Practice crisis-communications role responsibilities.",
        "audience":"Communications team","delivery_type":"Workshop","mission_lenses":["Protection","Response"],
        "commercial_treatment":"Membership Included","membership_entitlement_ref":"SYNTHETIC-QUARTERLY-TRAINING"})
    assert training.status_code==200,training.text
    training_id=training.json()["id"]
    assert client.get("/api/salops/preparedness/training",headers=member).json()==[]
    assert client.post(f"/api/salops/preparedness/training/{training_id}/release",headers=salus,json={"approved_for_member":True,"reason":"Approved member schedule visibility."}).status_code==200
    assert len(client.get("/api/salops/preparedness/training",headers=member).json())==1
    complete=client.post(f"/api/salops/preparedness/training/{training_id}/complete",headers=salus,json={
        "performance_check":"Role responsibilities recalled.","observations":"Re-test backup spokesperson under exercise conditions.",
        "follow_up_requirements":"Conduct defensive tabletop.","evidence_refs":["SYNTHETIC-ATTENDANCE"],"reason":"Training completed; readiness not inferred."})
    assert complete.status_code==200 and complete.json()["status"]=="Completed"

    exercise=client.post("/api/salops/preparedness/exercises",headers=salus,json={
        "plan_id":plan_id,"title":"SYNTHETIC Crisis Communications Tabletop","exercise_type":"Tabletop Exercise",
        "purpose":"Test decision, notification and alternate-spokesperson procedures.",
        "objectives":["Test notification chain","Test alternate spokesperson"],"capabilities":["Public Information and Warning"],
        "scope_statement":"SYNTHETIC headquarters communications team only.","portfolio_scope":{"facilities":["SYNTHETIC-HQ"],"dynamic_inclusion":False},
        "mission_lenses":["Protection","Response","Recovery"],"scenario_summary":"Synthetic defensive crisis-communications disruption.",
        "scenario_control":{"controller_note":"Internal exercise-control material"},
        "evaluation_criteria":["Decision authority identified","Alternate spokesperson activated"],
        "safety_real_world_controls":"Stop exercise immediately for any real-world emergency.",
        "commercial_treatment":"Preferred Rate"})
    assert exercise.status_code==200,exercise.text
    exercise_id=exercise.json()["id"]
    assert client.get(f"/api/salops/preparedness/exercises/{exercise_id}",headers=member).status_code==403
    inject=client.post(f"/api/salops/preparedness/exercises/{exercise_id}/injects",headers=salus,json={
        "sequence_no":1,"title":"SYNTHETIC spokesperson unavailable","inject_text":"Primary spokesperson is unavailable; participants identify approved alternate communications actions.",
        "expected_decision":"Identify alternate spokesperson and approval path."})
    assert inject.status_code==200,inject.text
    for status in ("Reviewed","Approved","In Progress","Completed"):
        r=client.post(f"/api/salops/preparedness/exercises/{exercise_id}/transition",headers=salus,json={"status":status,"reason":"SYNTHETIC governed exercise lifecycle."})
        assert r.status_code==200,r.text
    member_exercise=client.get(f"/api/salops/preparedness/exercises/{exercise_id}",headers=member)
    assert member_exercise.status_code==200,member_exercise.text
    assert member_exercise.json()["injects"]==[] and "scenario_control" not in member_exercise.json()["exercise"]

    observation=client.post(f"/api/salops/preparedness/exercises/{exercise_id}/observations",headers=salus,json={
        "epistemic_state":"Verified Fact","title":"SYNTHETIC alternate spokesperson gap",
        "observation":"Exercise participants could not identify the approved alternate spokesperson.",
        "expected_standard":"Plan requires an alternate spokesperson.","what_occurred":"No alternate was identified during the exercise.",
        "deficiency_gap":"Single-person communications dependency.","corrective_recommendation":"Designate, train and re-test an alternate spokesperson.",
        "source_refs":["SYNTHETIC-EVALUATOR-NOTE-1"]})
    assert observation.status_code==200,observation.text
    observation_id=observation.json()["id"]
    assert client.post(f"/api/salops/preparedness/observations/{observation_id}/release",headers=salus,json={"approved_for_member":True,"reason":"Qualified exercise finding released."}).status_code==200

    action=client.post("/api/salops/preparedness/corrective-actions",headers=salus,json={
        "observation_id":observation_id,"exercise_id":exercise_id,"plan_id":plan_id,
        "title":"SYNTHETIC Designate alternate spokesperson","description":"Assign, train and validate an alternate spokesperson.",
        "owner":"Communications Director","priority":"High","validation_method":"Re-test through a communications drill.","reexercise_required":True,
        "membership_entitlement_ref":"SYNTHETIC-CORRECTIVE-REVIEW"})
    assert action.status_code==200,action.text
    action_id=action.json()["id"]
    assert client.post(f"/api/salops/preparedness/corrective-actions/{action_id}/transition",headers=salus,json={"status":"In Progress","reason":"Owner began corrective work."}).status_code==200
    premature=client.post(f"/api/salops/preparedness/corrective-actions/{action_id}/transition",headers=salus,json={"status":"Implemented","reason":"Attempt without completion evidence."})
    assert premature.status_code==409
    assert client.post(f"/api/salops/preparedness/corrective-actions/{action_id}/transition",headers=salus,json={"status":"Implemented","reason":"Implementation evidence received.","completion_evidence":["SYNTHETIC-ROLE-ASSIGNMENT"]}).status_code==200
    assert client.post(f"/api/salops/preparedness/corrective-actions/{action_id}/transition",headers=salus,json={"status":"Awaiting Validation","reason":"Implementation awaits independent re-test."}).status_code==200
    assert client.post(f"/api/salops/preparedness/corrective-actions/{action_id}/transition",headers=salus,json={"status":"Validated","reason":"Re-test completed.","validation_result":"Alternate spokesperson performed the required role in the synthetic drill."}).status_code==200
    assert client.post(f"/api/salops/preparedness/corrective-actions/{action_id}/release",headers=salus,json={"approved_for_member":True,"reason":"Validated corrective status released."}).status_code==200

    aar=client.post("/api/salops/preparedness/aars",headers=salus,json={"exercise_id":exercise_id,"executive_summary":"SYNTHETIC tabletop identified an alternate-spokesperson resilience gap."})
    assert aar.status_code==200,aar.text
    aar_id=aar.json()["id"]
    for status in ("Reviewed","Approved","Released"):
        r=client.post(f"/api/salops/preparedness/aars/{aar_id}/transition",headers=salus,json={"status":status,"reason":"SYNTHETIC governed AAR/IP release."})
        assert r.status_code==200,r.text
    assert len(client.get("/api/salops/preparedness/aars",headers=member).json())==1

    chat=client.post("/api/salops/preparedness/chat-work",headers=salus,json={
        "linked_entity_type":"Exercise","linked_entity_id":exercise_id,"task_type":"Evaluation Analysis",
        "purpose":"Synthesize source-grounded exercise observations for Salus human review.",
        "authorized_sources":["Governed exercise observation"],"source_refs":[observation_id],
        "provider":"ChatGPT","model":"GPT-5.6 Sol","output_summary":"Draft analysis for human qualification.",
        "output":{"known_unknowns":["Long-term alternate spokesperson sustainment cadence"]}})
    assert chat.status_code==200,chat.text
    chat_id=chat.json()["id"]
    assert client.get("/api/salops/preparedness/chat-work",headers=member).status_code==403
    assert client.post(f"/api/salops/preparedness/chat-work/{chat_id}/review",headers=salus,json={"status":"Qualified","reason":"Salus human reviewer qualified the source-grounded draft."}).status_code==200

    # Tenant isolation: a second tenant cannot fetch tenant 1 records.
    conn=app.db();conn.execute("INSERT INTO tenants(id,name,slug,status,created_at) VALUES(2,'Other Tenant','other-prep','Active',?) ON CONFLICT(id) DO NOTHING",(app.now(),));conn.commit();conn.close()
    assert client.get(f"/api/salops/preparedness/plans/{plan_id}",headers=other).status_code==404

    # The runtime backup hooks include Issue #162 records and validate their relationships.
    conn=app.db();records=app.collect_tenant_records(conn,1);errors=app.validate_records(records,1);assert not errors,errors
    assert len(records["salops_preparedness_plans"])==1
    assert len(records["salops_preparedness_exercises"])==1
    assert len(records["salops_preparedness_observations"])==1
    assert len(records["salops_preparedness_corrective_actions"])==1
    assert len(records["salops_preparedness_aars"])==1
    app.replace_tenant_records(conn,1,records);conn.commit()
    restored=conn.execute("SELECT COUNT(*) c FROM salops_preparedness_exercises WHERE tenant_id=1").fetchone()["c"];conn.close();assert restored==1

    print("SALOPS_PREPAREDNESS_SMOKE_PASS")


if __name__ == "__main__":
    main()
