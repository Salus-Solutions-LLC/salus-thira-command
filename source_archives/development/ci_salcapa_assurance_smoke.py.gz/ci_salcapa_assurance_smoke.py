#!/usr/bin/env python3
"""Acceptance checks for the server-derived SalCAPA PROVE foundation."""
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORKSPACE = tempfile.TemporaryDirectory()
os.environ.setdefault("SALUS_DB_BACKEND", "sqlite")
os.environ.setdefault("SALUS_DB_PATH", str(Path(WORKSPACE.name) / "assurance.db"))
os.environ.setdefault("SALUS_BACKUP_DIR", str(Path(WORKSPACE.name) / "backups"))
os.environ.setdefault("SALUS_LOCAL_STORAGE_DIR", str(Path(WORKSPACE.name) / "attachments"))
os.environ.setdefault("SALUS_AUTH_MODE", "prototype")
os.environ.setdefault("SALUS_SEED_DEMO", "1")
sys.path.insert(0, str(ROOT))

from fastapi.testclient import TestClient
import salcapa_runtime


def main():
    client = TestClient(salcapa_runtime.app)
    analyst = {"X-Salus-Tenant": "1", "X-Salus-Role": "Assessment Director",
               "X-Salus-User": "Assurance Director", "X-Salus-Clearance": "Highly Sensitive"}
    member = {"X-Salus-Tenant": "1", "X-Salus-Role": "Contributor",
              "X-Salus-User": "Protected Member", "X-Salus-Clearance": "Standard"}
    other = {"X-Salus-Tenant": "2", "X-Salus-Role": "Assessment Director",
             "X-Salus-User": "Other Tenant", "X-Salus-Clearance": "Highly Sensitive"}

    assert client.get("/api/system/mode").json()["version"] == "3.59"
    root = client.get("/")
    assert root.status_code == 200
    for marker in ('data-view="prove"', "/static/salcapa-assurance.css",
                   "/static/salcapa-assurance.js", "/static/salcapa-display.js"):
        assert marker in root.text, marker

    stamp = salcapa_runtime.core.now()
    conn = salcapa_runtime.core.db()
    conn.execute(
        "INSERT INTO intel_findings(tenant_id,assessment_id,title,source,relevance,credibility,"
        "validation_status,operational_significance,status,qualified_by,qualified_at,created_by,"
        "created_at,updated_at) VALUES(1,1,?,'Synthetic governed source','Relevant','High',"
        "'Qualified','Supports synthetic assurance trace','Sent to SalTHIRA',?,?,?, ?,?)",
        ("SYNTHETIC qualified intelligence", "Assurance Director", stamp,
         "Assurance Director", stamp, stamp),
    )
    intel_id = int(conn.execute("SELECT MAX(id) id FROM intel_findings").fetchone()["id"])
    conn.execute(
        "INSERT INTO reassessment_triggers(assessment_id,source,trigger_type,description,severity,"
        "affected_record_type,affected_record_id,status,created_at,updated_at) "
        "VALUES(1,'SalINTEL','Qualified Intelligence','Synthetic explicit trace','High',"
        "'intel_finding',?,'Open',?,?)", (intel_id, stamp, stamp),
    )
    for title, sensitivity in (("SYNTHETIC member-safe evidence", "Standard"),
                               ("SYNTHETIC restricted evidence", "Highly Sensitive")):
        conn.execute(
            "INSERT INTO evidence(assessment_id,capability_id,title,verification_status,"
            "lifecycle_status,sensitivity,created_at,updated_at) "
            "VALUES(1,1,?,'Verified','Current',?,?,?)", (title, sensitivity, stamp, stamp),
        )
    conn.execute(
        "INSERT INTO decisions(assessment_id,improvement_id,decision_type,authority,rationale,"
        "created_at,updated_at) VALUES(1,1,'Approve','Synthetic Authority',"
        "'Synthetic approval without action for gap testing',?,?)", (stamp, stamp),
    )
    conn.commit()
    conn.close()

    path = "/api/salcapa/assurance?assessment_id=1"
    response = client.get(path, headers=analyst)
    assert response.status_code == 200, response.text
    data = response.json()
    assert data["workspace"] == "PROVE — Assurance & Results"
    assert data["cross_cutting"] is True and data["not_a_separate_product"] is True
    result = data["assessments"][0]
    assert result["trace_policy"] == {
        "server_derived": True, "explicit_links_only": True,
        "missing_links_are_gaps": True, "automatic_completion": False,
        "automatic_disclosure": False, "automatic_authority": False,
    }
    stages = {item["key"]: item for item in result["stages"]}
    assert list(stages) == [
        "qualified_intelligence", "risk_priority", "decision", "authorized_action",
        "execution", "evidence", "result_validation", "reassessment",
    ]
    assert stages["qualified_intelligence"]["record_count"] == 1
    assert stages["evidence"]["record_count"] == 2
    assert stages["authorized_action"]["state"] == "Assurance gap"
    edges = {(item["source"], item["target"]) for item in result["explicit_edges"]}
    assert (f"intel_finding:{intel_id}", "reassessment_trigger:1") in edges
    assert ("threat:1", "scenario:1") in edges
    assert ("scenario:1", "capability:1") in edges
    assert ("capability:1", "gap:1") in edges
    assert ("gap:1", "improvement:1") in edges
    assert ("improvement:1", "decision:1") in edges
    gap_keys = {item["gap_key"] for item in result["assurance_gaps"]}
    assert "decision:1:action" in gap_keys
    assert client.post(path, headers=analyst, json={"complete": True}).status_code == 405

    member_response = client.get(path, headers=member)
    assert member_response.status_code == 200, member_response.text
    member_result = member_response.json()["assessments"][0]
    assert member_result["stages"][5]["record_count"] == 1
    evidence_nodes = [item for item in member_result["nodes"] if item["record_type"] == "evidence"]
    assert [item["label"] for item in evidence_nodes] == ["SYNTHETIC member-safe evidence"]
    assert client.get(path, headers=other).status_code == 403
    print("SALCAPA_ASSURANCE_SMOKE_PASS")


if __name__ == "__main__":
    main()
