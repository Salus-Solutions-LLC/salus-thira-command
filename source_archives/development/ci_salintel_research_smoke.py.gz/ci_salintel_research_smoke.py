#!/usr/bin/env python3
"""Acceptance checks for Chat-led research truth and mixed-source reconciliation."""
import json
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORKSPACE = tempfile.TemporaryDirectory()
os.environ.setdefault("SALUS_DB_BACKEND", "sqlite")
os.environ.setdefault("SALUS_DB_PATH", str(Path(WORKSPACE.name) / "research.db"))
os.environ.setdefault("SALUS_BACKUP_DIR", str(Path(WORKSPACE.name) / "backups"))
os.environ.setdefault("SALUS_LOCAL_STORAGE_DIR", str(Path(WORKSPACE.name) / "attachments"))
os.environ.setdefault("SALUS_AUTH_MODE", "prototype")
os.environ.setdefault("SALUS_SEED_DEMO", "1")
sys.path.insert(0, str(ROOT))

from fastapi.testclient import TestClient
import salcapa_runtime
from portable_backup import collect_tenant_records, replace_tenant_records, validate_records

app = salcapa_runtime.core


def main():
    client = TestClient(salcapa_runtime.app)
    analyst = {"X-Salus-Tenant": "1", "X-Salus-Role": "Assessment Director",
               "X-Salus-User": "Research Supervisor",
               "X-Salus-Clearance": "Highly Sensitive"}
    member = {"X-Salus-Tenant": "1", "X-Salus-Role": "Contributor",
              "X-Salus-User": "Protected Member User"}

    created = client.post("/api/salintel/investigations", headers=analyst, json={
        "domain_key": "personnel-assessment",
        "title": "SYNTHETIC Chat-led Personnel Investigation",
        "subject_reference": "SYNTHETIC-PERSON-CHAT-001",
        "purpose": "Lawful synthetic research workflow acceptance.",
        "requested_tier": 1, "sensitivity": "Sensitive"})
    assert created.status_code == 200, created.text
    investigation_id = created.json()["id"]
    assert client.post(f"/api/salintel/investigations/{investigation_id}/research-plans",
        headers=analyst, json={"reason": "No tier yet."}).status_code == 409
    authorized = client.post(
        f"/api/salintel/investigations/{investigation_id}/authorize-tier",
        headers=analyst, json={
            "authorized_tier": 1,
            "scope_statement": "Identity, core claims, readily available sources, contradictions and known unknowns.",
            "checklist_version": "personnel-assessment-1.0",
            "effort_bounds": {"maximum_human_hours": 2, "chat_cost_allowance_usd": 4},
            "source_categories": ["lawful public sources", "member-provided records"],
            "exclusions": ["unrestricted dossiers", "deep network expansion"],
            "commercial_treatment": "Included",
            "commercial_reference": "SYNTHETIC-CHAT-T1",
            "investigative_lenses": ["Prevention", "Protection"],
            "reason": "Authorize bounded Tier 1 Chat and human research."})
    assert authorized.status_code == 200, authorized.text
    personnel_plan = client.post(
        f"/api/salintel/personnel-assessments/{investigation_id}/research-plan",
        headers=analyst, json={"reason": "Generate domain checklist."})
    assert personnel_plan.status_code == 200, personnel_plan.text

    forged = client.post(f"/api/salintel/investigations/{investigation_id}/research-plans",
        headers=analyst, json={"reason": "Attempt forgery.", "authorized_tier": 3,
                               "authorized_by": "Client"})
    assert forged.status_code == 422
    plan = client.post(f"/api/salintel/investigations/{investigation_id}/research-plans",
        headers=analyst, json={"reason": "Authorize combined Chat, human, member, and material collection plan."})
    assert plan.status_code == 200, plan.text
    plan_id = plan.json()["id"]
    assert plan.json()["authorized_tier"] == 1 and plan.json()["task_count"] >= 8
    assert client.post(f"/api/salintel/investigations/{investigation_id}/research-plans",
        headers=analyst, json={"reason": "Duplicate."}).status_code == 409
    assert client.get(f"/api/salintel/investigations/{investigation_id}/research",
                      headers=member).status_code == 403

    view = client.get(f"/api/salintel/investigations/{investigation_id}/research",
                      headers=analyst)
    assert view.status_code == 200, view.text
    data = view.json()
    contributors = {task["contributor"] for task in data["tasks"]}
    assert {"Chat Research", "Salus Human Investigator", "Protected Member / Form",
            "Document / Material"} <= contributors
    chat_task = next(task for task in data["tasks"] if task["contributor"] == "Chat Research")
    human_task = next(task for task in data["tasks"]
                      if task["contributor"] == "Salus Human Investigator")
    assert client.post(
        f"/api/salintel/investigations/{investigation_id}/research-plans/{plan_id}/executions",
        headers=analyst, json={"task_key": human_task["task_key"],
        "adapter": "Governed Material Search", "reason": "Invalid contributor."}
    ).status_code == 422
    assert client.post(
        f"/api/salintel/investigations/{investigation_id}/research-plans/{plan_id}/executions",
        headers=analyst, json={"task_key": chat_task["task_key"],
        "adapter": "Governed Material Search", "reason": "Attempt client forgery.",
        "external_network_accessed": True}
    ).status_code == 422

    no_bytes = client.post(
        f"/api/salintel/investigations/{investigation_id}/research-plans/{plan_id}/source-results",
        headers=analyst, json={"task_key": chat_task["task_key"], "outcome": "Accessed",
        "source_title": "Claimed source", "source_locator": "https://example.invalid/source",
        "notes": "Must not claim access without governed source material."})
    assert no_bytes.status_code == 409
    wrong_outcome = client.post(
        f"/api/salintel/investigations/{investigation_id}/research-plans/{plan_id}/source-results",
        headers=analyst, json={"task_key": chat_task["task_key"],
        "outcome": "Human Collection Received", "source_title": "Wrong contributor",
        "notes": "A Chat task cannot masquerade as human collection."})
    assert wrong_outcome.status_code == 422

    material = client.post("/api/materials/upload", headers=analyst, data={
        "title": "SYNTHETIC Chat-accessed public source", "material_kind": "Document",
        "source_origin": "Authorized synthetic public record", "sensitivity": "Sensitive",
        "purpose_tags": json.dumps(["SalINTEL", "Chat Research"])},
        files={"file": ("chat-source.txt", b"SYNTHETIC CHAT-ACCESSED SOURCE\n", "text/plain")})
    assert material.status_code == 200, material.text
    material_id = material.json()["id"]
    for state, reason in (("Processing", "Begin extraction."),
                          ("Ready for Human Review", "Human reviewed source capture.")):
        transition = client.post(f"/api/materials/{material_id}/transition",
            headers=analyst, json={"status": state, "reason": reason})
        assert transition.status_code == 200, transition.text
    linked = client.post(f"/api/materials/{material_id}/links", headers=analyst,
        json={"target_type": "salintel_investigation", "target_id": investigation_id,
              "purpose": "Preserve source bytes and provenance for Chat research."})
    assert linked.status_code == 200, linked.text

    executed = client.post(
        f"/api/salintel/investigations/{investigation_id}/research-plans/{plan_id}/executions",
        headers=analyst, json={"task_key": chat_task["task_key"],
        "adapter": "Governed Material Search",
        "reason": "Execute the authorized internal source search."})
    assert executed.status_code == 200, executed.text
    assert executed.json()["status"] == "Completed"
    assert executed.json()["match_count"] == 1
    assert executed.json()["external_network_accessed"] is False
    assert executed.json()["external_cost_incurred"] is False
    accessed_id = executed.json()["source_result_ids"][0]

    premature = client.post(
        f"/api/salintel/investigations/{investigation_id}/research-plans/{plan_id}/products",
        headers=analyst, json={"executive_summary": "Premature synthesis.",
        "findings": [{"statement": "A premature inference.",
                      "epistemic_state": "Reasonable Inference"}],
        "known_unknowns": "Tasks remain open.",
        "completion_statement": "Not complete."})
    assert premature.status_code == 409

    outcome_for = {
        "Chat Research": "Unavailable",
        "Salus Human Investigator": "Requires Human Collection",
        "Protected Member / Form": "Requires Protected Member Input",
        "Document / Material": "Unavailable",
        "Prior SalCAPA Context": "Unavailable",
        "Approved Partner Return": "Requires Partner Authorization",
    }
    for task in data["tasks"]:
        if task["task_key"] == chat_task["task_key"]:
            continue
        outcome = outcome_for[task["contributor"]]
        response = client.post(
            f"/api/salintel/investigations/{investigation_id}/research-plans/{plan_id}/source-results",
            headers=analyst, json={"task_key": task["task_key"], "outcome": outcome,
            "source_title": f"SYNTHETIC disposition for {task['task_key']}",
            "notes": "Truthfully recorded stopping point or collection requirement within the authorized tier."})
        assert response.status_code == 200, response.text

    ready = client.get(f"/api/salintel/investigations/{investigation_id}/research",
                       headers=analyst).json()
    assert ready["ready_for_synthesis"] is True
    assert ready["progress"]["open"] == 0
    assert ready["progress"]["chat_sources_accessed"] == 1
    assert ready["progress"]["tool_executions"] == 1
    assert len(ready["executions"]) == 1
    execution_detail = ready["executions"][0]["structured_detail"]
    assert execution_detail["query_derived_by_server"] is True
    assert execution_detail["matched_material_ids"] == [material_id]
    assert execution_detail["source_bytes_duplicated"] is False
    forged_fact = client.post(
        f"/api/salintel/investigations/{investigation_id}/research-plans/{plan_id}/products",
        headers=analyst, json={"executive_summary": "Synthetic summary.",
        "findings": [{"statement": "Chat cannot self-verify a fact.",
                      "epistemic_state": "Verified Fact", "source_result_ids": [accessed_id]}],
        "known_unknowns": "Unavailable sources remain.",
        "completion_statement": "Bounded Chat research is complete."})
    assert forged_fact.status_code == 422

    product = client.post(
        f"/api/salintel/investigations/{investigation_id}/research-plans/{plan_id}/products",
        headers=analyst, json={
            "executive_summary": "Chat completed genuine bounded research against one captured source and preserved all unavailable and human-collection needs.",
            "findings": [
                {"statement": "The accessed synthetic record reports a current professional association.",
                 "epistemic_state": "Reported Information", "source_result_ids": [accessed_id],
                 "information_confidence": "Moderate"},
                {"statement": "Additional human verification is required before qualification.",
                 "epistemic_state": "Information Gap", "source_result_ids": []}],
            "contradictions": "No contradiction was resolved from the bounded source set.",
            "known_unknowns": "Human, member, and unavailable-source requirements remain explicitly governed.",
            "implications": "No adverse or operational conclusion is authorized from this unqualified product.",
            "completion_statement": "The authorized Chat-research portion is complete within its bounded sources and tool availability.",
            "deeper_tier_recommended": True,
            "deeper_tier_reason": "A separately authorized deeper tier may address residual source gaps."})
    assert product.status_code == 200, product.text
    product_id = product.json()["id"]
    notification_id = product.json()["notification_id"]
    assert product.json()["review_status"] == "Awaiting Human Review"
    assert product.json()["tier_change_authorized"] is False
    assert product.json()["external_escalation_authorized"] is False
    notified = client.get(f"/api/salintel/investigations/{investigation_id}/research",
                          headers=analyst).json()
    assert notified["progress"]["unread_notifications"] == 1
    notice = next(item for item in notified["notifications"]
                  if item["id"] == notification_id)["structured_detail"]
    assert notice["recipient_scope"] == "Authorized Salus Personnel"
    assert notice["external_delivery"] is False
    assert client.post(
        f"/api/salintel/investigations/{investigation_id}/research-notifications/{notification_id}/acknowledge",
        headers=member, json={"reason": "Member forgery."}).status_code == 403
    assert client.post(
        f"/api/salintel/investigations/{investigation_id}/research-notifications/{notification_id}/acknowledge",
        headers=analyst, json={"reason": "Attempt status forgery.", "status": "Resolved"}
    ).status_code == 422
    acknowledged = client.post(
        f"/api/salintel/investigations/{investigation_id}/research-notifications/{notification_id}/acknowledge",
        headers=analyst, json={"reason": "Salus reviewer accepted the review assignment."})
    assert acknowledged.status_code == 200, acknowledged.text
    assert acknowledged.json()["status"] == "Acknowledged"
    assert client.post(
        f"/api/salintel/investigations/{investigation_id}/research-products/{product_id}/review",
        headers=member, json={"status": "Qualified", "reason": "Member forgery."}
    ).status_code == 403
    reviewed = client.post(
        f"/api/salintel/investigations/{investigation_id}/research-products/{product_id}/review",
        headers=analyst, json={"status": "Qualified",
        "reason": "Salus reviewer challenged the citations, inferences, unavailable sources, and stopping point."})
    assert reviewed.status_code == 200, reviewed.text
    assert reviewed.json()["member_visible"] is False
    assert reviewed.json()["investigation_qualification_status"] == "Unqualified"
    resolved = client.get(f"/api/salintel/investigations/{investigation_id}/research",
                          headers=analyst).json()
    resolved_notice = next(item for item in resolved["notifications"]
                           if item["id"] == notification_id)["structured_detail"]
    assert resolved_notice["status"] == "Resolved"

    conn = app.db()
    records = collect_tenant_records(conn, 1)
    assert not validate_records(records, 1)
    material_count = len(records["materials"])
    research_rows = [row for row in records["salintel_investigation_items"]
                     if str(row.get("item_key", "")).startswith(
                         ("SIRP-", "SIRS-", "SIPR-", "SIXE-", "SIN-"))]
    assert len(research_rows) == 4 + len(data["tasks"])
    replace_tenant_records(conn, 1, records)
    conn.commit()
    assert conn.execute("SELECT COUNT(*) c FROM materials WHERE tenant_id=1").fetchone()["c"] == material_count
    conn.execute("INSERT INTO tenants(id,name,slug,status,created_at) "
                 "VALUES(2,'Other Tenant','other-research','Active',?) "
                 "ON CONFLICT(id) DO NOTHING", (app.now(),))
    conn.commit(); conn.close()
    other = {**analyst, "X-Salus-Tenant": "2", "X-Salus-User": "Other Analyst"}
    assert client.get(f"/api/salintel/investigations/{investigation_id}/research",
                      headers=other).status_code == 403

    events = client.get(f"/api/salintel/investigations/{investigation_id}",
                        headers=analyst).json()["events"]
    versions = [event["version_no"] for event in events]
    assert versions == list(range(1, len(versions) + 1))
    assert any(event["event_type"] == "SALINTEL_RESEARCH_PLAN_AUTHORIZED" for event in events)
    assert any(event["event_type"] == "SALINTEL_RESEARCH_PRODUCT_READY_FOR_REVIEW" for event in events)
    assert any(event["event_type"] == "SALINTEL_RESEARCH_TOOL_EXECUTED" for event in events)
    assert any(event["event_type"] == "SALINTEL_RESEARCH_REVIEW_NOTIFICATION_DELIVERED" for event in events)
    assert any(event["event_type"] == "SALINTEL_RESEARCH_REVIEW_NOTIFICATION_ACKNOWLEDGED" for event in events)
    assert any(event["event_type"] == "SALINTEL_RESEARCH_PRODUCT_REVIEWED" for event in events)
    print("SALCAPA_SALINTEL_CHAT_RESEARCH_PASS", app.DB_BACKEND)


if __name__ == "__main__":
    main()
