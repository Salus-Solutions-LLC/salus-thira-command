"""Governed Chat-led research and mixed-source reconciliation for SalINTEL.

Plans, source-access truth records, and synthesis products use the shared
investigative-item model. Source bytes remain in governed material records.
"""
from __future__ import annotations

import json
import re
import uuid
from typing import Literal

from fastapi import HTTPException, Request
from pydantic import BaseModel, ConfigDict, Field, field_validator

PLAN_VERSION = "salintel-research-1.0"
Contributor = Literal[
    "Chat Research", "Salus Human Investigator", "Protected Member / Form",
    "Document / Material", "Prior SalCAPA Context", "Approved Partner Return",
]
Outcome = Literal[
    "Accessed", "Unavailable", "Requires Human Collection",
    "Requires Protected Member Input", "Requires Partner Authorization",
    "Human Collection Received", "Protected Member Input Received",
    "Document / Material Received", "Prior SalCAPA Context Reused",
    "Approved Partner Return Received",
]
ChatEpistemic = Literal[
    "Reported Information", "Reasonable Inference", "Hypothesis",
    "Contradiction", "Information Gap", "Unknown",
]
ReviewState = Literal["Analyst Reviewed", "Qualified", "Rejected"]
ResearchAdapter = Literal["Governed Material Search"]

REQUIRES_MATERIAL = {
    "Accessed", "Human Collection Received", "Protected Member Input Received",
    "Document / Material Received", "Approved Partner Return Received",
}
OUTCOMES = {
    "Chat Research": {"Accessed", "Unavailable", "Requires Human Collection",
                      "Requires Protected Member Input", "Requires Partner Authorization"},
    "Salus Human Investigator": {"Human Collection Received", "Requires Human Collection",
                                 "Unavailable"},
    "Protected Member / Form": {"Protected Member Input Received",
                                "Requires Protected Member Input", "Unavailable"},
    "Document / Material": {"Document / Material Received", "Unavailable",
                            "Requires Human Collection", "Requires Protected Member Input"},
    "Prior SalCAPA Context": {"Prior SalCAPA Context Reused", "Unavailable"},
    "Approved Partner Return": {"Approved Partner Return Received",
                                "Requires Partner Authorization", "Unavailable"},
}


class CreateResearchPlan(BaseModel):
    model_config = ConfigDict(extra="forbid")
    reason: str = Field(min_length=1, max_length=4000)


class RecordSourceResult(BaseModel):
    model_config = ConfigDict(extra="forbid")
    task_key: str = Field(min_length=1, max_length=180)
    outcome: Outcome
    source_title: str = Field(min_length=1, max_length=500)
    source_locator: str = Field(default="", max_length=2000)
    notes: str = Field(min_length=1, max_length=8000)
    source_reliability: str = Field(default="Not Assessed", max_length=80)
    information_confidence: str = Field(default="Not Assessed", max_length=80)
    source_material_id: int | None = Field(default=None, gt=0)
    related_investigation_id: int | None = Field(default=None, gt=0)


class ProductFinding(BaseModel):
    model_config = ConfigDict(extra="forbid")
    statement: str = Field(min_length=1, max_length=8000)
    epistemic_state: ChatEpistemic
    source_result_ids: list[int] = Field(default_factory=list, max_length=100)
    information_confidence: str = Field(default="Not Assessed", max_length=80)
    implications: str = Field(default="", max_length=4000)


class CreateResearchProduct(BaseModel):
    model_config = ConfigDict(extra="forbid")
    executive_summary: str = Field(min_length=1, max_length=12000)
    findings: list[ProductFinding] = Field(min_length=1, max_length=200)
    contradictions: str = Field(default="", max_length=8000)
    known_unknowns: str = Field(min_length=1, max_length=8000)
    implications: str = Field(default="", max_length=8000)
    completion_statement: str = Field(min_length=1, max_length=8000)
    deeper_tier_recommended: bool = False
    deeper_tier_reason: str = Field(default="", max_length=4000)


class ReviewResearchProduct(BaseModel):
    model_config = ConfigDict(extra="forbid")
    status: ReviewState
    reason: str = Field(min_length=1, max_length=4000)


class ExecuteResearchTask(BaseModel):
    model_config = ConfigDict(extra="forbid")
    task_key: str = Field(min_length=1, max_length=180)
    adapter: ResearchAdapter
    reason: str = Field(min_length=1, max_length=4000)


class AcknowledgeNotification(BaseModel):
    model_config = ConfigDict(extra="forbid")
    reason: str = Field(min_length=1, max_length=4000)


def register_salintel_research(app, core: dict) -> None:
    db, now = core["db"], core["now"]
    actor, role, tenant_id = core["actor"], core["role"], core["tenant_id"]
    require = core["require"]
    authority = core["require_salus_component_authority"]
    require_sensitivity = core["require_sensitivity"]
    security_event = core["security_event"]

    def canonical(value):
        return json.dumps(value, sort_keys=True, separators=(",", ":"),
                          ensure_ascii=False, default=str)

    def salus(request: Request, action: str):
        require(request, "read")
        authority(request, f"SalINTEL research {action}")

    def investigation(conn, record_id: int, request: Request):
        row = conn.execute(
            "SELECT * FROM salintel_investigations WHERE id=?", (record_id,)
        ).fetchone()
        if not row:
            raise HTTPException(404, "SalINTEL investigation not found")
        if int(row["tenant_id"]) != tenant_id(request):
            security_event(request, "SALINTEL_RESEARCH_TENANT_BOUNDARY_VIOLATION",
                           "High", f"investigation_id={record_id}")
            raise HTTPException(403, "Tenant boundary violation")
        require_sensitivity(request, row["sensitivity"])
        return row

    def parsed(value, fallback):
        try:
            result = json.loads(value)
            return result
        except (TypeError, ValueError, json.JSONDecodeError):
            return fallback

    def item_detail(item):
        value = parsed(item["detail"], {})
        return value if isinstance(value, dict) else {}

    def research_items(conn, investigation_id: int):
        rows = []
        for row in conn.execute(
            "SELECT * FROM salintel_investigation_items WHERE investigation_id=? "
            "AND (item_key LIKE 'SIRP-%' OR item_key LIKE 'SIRS-%' "
            "OR item_key LIKE 'SIPR-%' OR item_key LIKE 'SIXE-%' "
            "OR item_key LIKE 'SIN-%') ORDER BY id", (investigation_id,),
        ):
            value = dict(row)
            value["structured_detail"] = item_detail(row)
            rows.append(value)
        return rows

    def event(conn, request: Request, record_id: int, event_type: str, reason: str):
        row = conn.execute(
            "SELECT * FROM salintel_investigations WHERE id=?", (record_id,)
        ).fetchone()
        version = int(conn.execute(
            "SELECT COUNT(*) c FROM salintel_investigation_events WHERE investigation_id=?",
            (record_id,),
        ).fetchone()["c"]) + 1
        conn.execute(
            "INSERT INTO salintel_investigation_events(tenant_id,investigation_id,version_no,"
            "event_type,reason,snapshot_json,changed_by,changed_by_role,created_at) "
            "VALUES(?,?,?,?,?,?,?,?,?)",
            (row["tenant_id"], record_id, version, event_type, reason[:4000],
             canonical(dict(row)), actor(request), role(request), now()),
        )

    def audit(conn, request: Request, action: str, item_id: int, detail: str):
        conn.execute(
            "INSERT INTO audit_log(ts,user_name,action,entity_type,entity_id,detail,tenant_id) "
            "VALUES(?,?,?,?,?,?,?)",
            (now(), actor(request), action, "salintel_research", item_id,
             detail[:2000], tenant_id(request)),
        )

    def create_item(conn, request: Request, row, prefix: str, kind: str,
                    epistemic: str, title: str, detail: dict,
                    reliability="Not Assessed", confidence="Not Assessed",
                    source_material_id=None):
        ts = now()
        cur = conn.execute(
            "INSERT INTO salintel_investigation_items(tenant_id,investigation_id,item_key,"
            "item_kind,epistemic_state,title,detail,source_reliability,"
            "information_confidence,source_material_id,member_visible,created_by,"
            "created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (row["tenant_id"], row["id"], prefix + uuid.uuid4().hex, kind,
             epistemic, title, canonical(detail), reliability.strip() or "Not Assessed",
             confidence.strip() or "Not Assessed", source_material_id, 0,
             actor(request), ts, ts),
        )
        return int(cur.lastrowid)

    def linked_material(conn, row, material_id: int, request: Request):
        material = conn.execute(
            "SELECT m.* FROM material_links l JOIN materials m ON m.id=l.material_id "
            "WHERE l.tenant_id=? AND l.material_id=? "
            "AND l.target_type='salintel_investigation' AND l.target_id=?",
            (row["tenant_id"], material_id, row["id"]),
        ).fetchone()
        if not material:
            raise HTTPException(409, "Research source must be governed and linked to the investigation")
        require_sensitivity(request, material["sensitivity"])
        return material

    def slug(value: str):
        return re.sub(r"[^A-Z0-9]+", "-", value.upper()).strip("-")[:70]

    def search_terms(*values: str):
        stop = {
            "about", "against", "authorized", "concerning", "conduct", "from",
            "high", "identify", "investigation", "material", "needed", "records",
            "research", "source", "sources", "that", "their", "this", "using",
            "what", "with",
        }
        terms = []
        for value in values:
            for term in re.findall(r"[A-Za-z0-9][A-Za-z0-9_-]{2,}", value.lower()):
                if term not in stop and term not in terms:
                    terms.append(term)
        return terms[:24]

    def map_contributor(channel: str):
        return {
            "Chat Research": "Chat Research",
            "Human Investigator": "Salus Human Investigator",
            "Analyst Assessment": "Salus Human Investigator",
            "Protected Member Input": "Protected Member / Form",
            "Source Extraction": "Document / Material",
            "Approved Partner Return": "Approved Partner Return",
        }.get(channel, "Document / Material")

    def generated_tasks(conn, row):
        tasks = []
        if row["domain_key"] == "personnel-assessment":
            for item in conn.execute(
                "SELECT * FROM salintel_investigation_items WHERE investigation_id=? ORDER BY id",
                (row["id"],),
            ):
                detail = item_detail(item)
                if detail.get("record_type") != "personnel_checklist":
                    continue
                contributors = []
                for channel in detail.get("collection_channels", []):
                    contributor = map_contributor(str(channel))
                    if contributor not in contributors:
                        contributors.append(contributor)
                for contributor in contributors:
                    key = f"T{row['authorized_tier']}-{detail.get('checklist_key')}-{slug(contributor)}"
                    tasks.append({
                        "task_key": key, "checklist_key": detail.get("checklist_key", ""),
                        "question": detail.get("question", item["title"]),
                        "contributor": contributor, "tier": int(row["authorized_tier"]),
                        "status": "Authorized",
                    })
        if not tasks:
            domain = conn.execute(
                "SELECT display_name,description FROM salintel_domains WHERE domain_key=?",
                (row["domain_key"],),
            ).fetchone()
            subject = row["subject_reference"]
            prompts = [
                ("Chat Research", f"Research authorized high-value sources concerning {subject}."),
                ("Salus Human Investigator", f"Identify human verification and interview needs for {subject}."),
                ("Protected Member / Form", f"Identify bounded Protected Member questions concerning {subject}."),
                ("Document / Material", f"Identify records and files needed to corroborate {subject}."),
                ("Prior SalCAPA Context", f"Review governed prior SalCAPA context related to {subject}."),
            ]
            if int(row["authorized_tier"]) >= 2:
                prompts.append(("Approved Partner Return",
                    "Identify specialized partner capability that may improve the authorized scope; do not transmit or incur cost."))
            for index, (contributor, question) in enumerate(prompts, 1):
                tasks.append({"task_key": f"T{row['authorized_tier']}-GEN-{index:02d}-{slug(contributor)}",
                              "checklist_key": "", "question": question,
                              "contributor": contributor, "tier": int(row["authorized_tier"]),
                              "status": "Authorized", "domain_name": domain["display_name"] if domain else row["domain_key"]})
        return tasks

    def plan_for(conn, investigation_id: int, plan_id: int, request: Request):
        row = investigation(conn, investigation_id, request)
        item = conn.execute(
            "SELECT * FROM salintel_investigation_items WHERE id=? AND investigation_id=?",
            (plan_id, investigation_id),
        ).fetchone()
        if not item or not item["item_key"].startswith("SIRP-"):
            raise HTTPException(404, "SalINTEL research plan not found")
        detail = item_detail(item)
        if detail.get("record_type") != "salintel_research_plan":
            raise HTTPException(404, "SalINTEL research plan not found")
        return row, dict(item), detail

    def status_view(conn, row, plan_item, plan_detail):
        items = research_items(conn, row["id"])
        results = [item for item in items if item["structured_detail"].get("record_type") == "salintel_source_result"
                   and int(item["structured_detail"].get("plan_id", 0)) == plan_item["id"]]
        products = [item for item in items if item["structured_detail"].get("record_type") == "salintel_research_product"
                    and int(item["structured_detail"].get("plan_id", 0)) == plan_item["id"]]
        executions = [item for item in items if item["structured_detail"].get("record_type") == "salintel_research_execution"
                      and int(item["structured_detail"].get("plan_id", 0)) == plan_item["id"]]
        notifications = [item for item in items if item["structured_detail"].get("record_type") == "salintel_research_notification"
                         and int(item["structured_detail"].get("plan_id", 0)) == plan_item["id"]]
        by_task = {}
        for result in results:
            by_task.setdefault(result["structured_detail"].get("task_key", ""), []).append(result)
        tasks = []
        for task in plan_detail.get("tasks", []):
            value = dict(task)
            value["results"] = by_task.get(task.get("task_key", ""), [])
            value["status"] = "Dispositioned" if value["results"] else "Open"
            tasks.append(value)
        accessed = [item for item in results if item["structured_detail"].get("outcome") == "Accessed"]
        return {"plan": {**plan_item, "structured_detail": plan_detail}, "tasks": tasks,
                "source_results": results, "products": products,
                "executions": executions, "notifications": notifications,
                "progress": {"total": len(tasks),
                             "dispositioned": sum(1 for task in tasks if task["results"]),
                             "open": sum(1 for task in tasks if not task["results"]),
                             "chat_sources_accessed": len(accessed),
                             "tool_executions": len(executions),
                             "unread_notifications": sum(
                                 1 for item in notifications
                                 if item["structured_detail"].get("status") == "Unread"
                             )},
                "ready_for_synthesis": bool(tasks) and all(task["results"] for task in tasks) and bool(accessed)}

    @app.post("/api/salintel/investigations/{investigation_id}/research-plans")
    def create_plan(investigation_id: int, payload: CreateResearchPlan, request: Request):
        salus(request, "planning")
        require(request, "decide")
        conn = db()
        try:
            row = investigation(conn, investigation_id, request)
            if int(row["authorized_tier"]) not in (1, 2, 3):
                raise HTTPException(409, "Authorize a bounded investigation tier first")
            if row["status"] in ("Tier Complete", "Closed"):
                raise HTTPException(409, "Completed work cannot be silently reopened")
            for item in research_items(conn, investigation_id):
                detail = item["structured_detail"]
                if (detail.get("record_type") == "salintel_research_plan"
                        and int(detail.get("authorized_tier", 0)) == int(row["authorized_tier"])):
                    raise HTTPException(409, "A research plan already exists for the authorized tier")
            tasks = generated_tasks(conn, row)
            if not any(task["contributor"] == "Chat Research" for task in tasks):
                tasks.insert(0, {"task_key": f"T{row['authorized_tier']}-CHAT-BASELINE",
                    "checklist_key": "", "question": "Conduct real authorized source research and preserve accessed and unavailable sources.",
                    "contributor": "Chat Research", "tier": int(row["authorized_tier"]),
                    "status": "Authorized"})
            detail = {"record_type": "salintel_research_plan", "plan_version": PLAN_VERSION,
                      "authorized_tier": int(row["authorized_tier"]),
                      "domain_key": row["domain_key"], "scope_snapshot": parsed(row["authorized_scope_json"], {}),
                      "source_categories": parsed(row["source_categories_json"], []),
                      "exclusions": parsed(row["exclusions_json"], []), "tasks": tasks,
                      "authorized_by": actor(request), "authorized_at": now(),
                      "authorization_reason": payload.reason.strip(), "status": "Authorized"}
            item_id = create_item(conn, request, row, "SIRP-", "Collection Requirement",
                                  "Information Gap", f"{PLAN_VERSION} — Tier {row['authorized_tier']}", detail)
            event(conn, request, investigation_id, "SALINTEL_RESEARCH_PLAN_AUTHORIZED",
                  f"plan_id={item_id}; tier={row['authorized_tier']}; tasks={len(tasks)}")
            audit(conn, request, "SALINTEL_RESEARCH_PLAN_AUTHORIZED", item_id,
                  f"investigation_id={investigation_id}; tier={row['authorized_tier']}; tasks={len(tasks)}")
            conn.commit()
            return {"id": item_id, "plan_version": PLAN_VERSION,
                    "authorized_tier": int(row["authorized_tier"]), "task_count": len(tasks)}
        finally:
            conn.close()

    @app.get("/api/salintel/investigations/{investigation_id}/research")
    def get_research(investigation_id: int, request: Request):
        salus(request, "review")
        conn = db()
        try:
            row = investigation(conn, investigation_id, request)
            plans = [item for item in research_items(conn, investigation_id)
                     if item["structured_detail"].get("record_type") == "salintel_research_plan"]
            if not plans:
                return {"investigation_id": investigation_id, "plan": None, "tasks": [],
                        "source_results": [], "products": [], "executions": [],
                        "notifications": [],
                        "progress": {"total": 0, "dispositioned": 0, "open": 0,
                                     "chat_sources_accessed": 0, "tool_executions": 0,
                                     "unread_notifications": 0},
                        "ready_for_synthesis": False}
            plan = plans[-1]
            return {"investigation_id": investigation_id,
                    **status_view(conn, row, plan, plan["structured_detail"])}
        finally:
            conn.close()

    @app.post("/api/salintel/investigations/{investigation_id}/research-plans/{plan_id}/executions")
    def execute_research_task(investigation_id: int, plan_id: int,
                              payload: ExecuteResearchTask, request: Request):
        """Execute a no-cost internal source tool within the authorized plan."""
        salus(request, "tool execution")
        require(request, "write")
        conn = db()
        try:
            row, plan_item, plan = plan_for(conn, investigation_id, plan_id, request)
            if row["status"] in ("Tier Complete", "Closed"):
                raise HTTPException(409, "Completed work cannot be silently reopened")
            task = next((item for item in plan.get("tasks", [])
                         if item.get("task_key") == payload.task_key), None)
            if not task:
                raise HTTPException(422, "Tool execution must reference an authorized research task")
            if task.get("contributor") != "Chat Research":
                raise HTTPException(422, "Chat research adapters may execute only Chat Research tasks")
            terms = search_terms(row["subject_reference"], task.get("question", ""))
            started_at = now()
            execution_detail = {
                "record_type": "salintel_research_execution", "schema_version": "1.0",
                "plan_id": plan_item["id"], "task_key": payload.task_key,
                "adapter": payload.adapter, "adapter_version": "1.0",
                "execution_mode": "Synchronous Governed Internal Search",
                "query_derived_by_server": True, "search_terms": terms,
                "authorized_task_question": task.get("question", ""),
                "authorized_tier": int(row["authorized_tier"]),
                "triggered_by": actor(request), "triggered_by_role": role(request),
                "authorization_reason": payload.reason.strip(),
                "started_at": started_at, "completed_at": "", "status": "Running",
                "external_network_accessed": False, "external_cost_incurred": False,
                "source_bytes_duplicated": False, "matched_material_ids": [],
                "source_result_ids": [], "member_visible": False,
            }
            execution_id = create_item(
                conn, request, row, "SIXE-", "Tool Execution", "Reported Information",
                f"{payload.adapter} — {payload.task_key}", execution_detail,
            )
            candidates = conn.execute(
                "SELECT m.* FROM material_links l JOIN materials m ON m.id=l.material_id "
                "WHERE l.tenant_id=? AND l.target_type='salintel_investigation' "
                "AND l.target_id=? ORDER BY m.id",
                (row["tenant_id"], row["id"]),
            ).fetchall()
            matches = []
            for material in candidates:
                if material["processing_status"] in ("Quarantined", "Rejected"):
                    continue
                try:
                    require_sensitivity(request, material["sensitivity"])
                except HTTPException:
                    continue
                searchable = " ".join(str(material[key] or "") for key in (
                    "title", "original_name", "source_origin", "source_locator", "description"
                )).lower()
                if terms and any(term in searchable for term in terms):
                    matches.append(material)
                if len(matches) == 20:
                    break
            result_ids = []
            if matches:
                for material in matches:
                    detail = {
                        "record_type": "salintel_source_result", "schema_version": "1.0",
                        "plan_id": plan_item["id"], "task_key": payload.task_key,
                        "authorized_contributor": "Chat Research", "outcome": "Accessed",
                        "source_title": material["title"],
                        "source_locator": f"salcapa://materials/{material['record_key']}",
                        "notes": "Governed Material Search matched and accessed the linked "
                                 "material record within the authorized investigation scope. "
                                 "Original source bytes remain governed by reference.",
                        "recorded_by": "SalCAPA Research Executor",
                        "recorded_by_role": "System Research Adapter",
                        "triggered_by": actor(request),
                        "acquired_or_recorded_at": now(),
                        "related_investigation_id": None,
                        "research_execution_id": execution_id,
                        "access_method": "Governed linked-material metadata search",
                        "material_processing_status": material["processing_status"],
                        "material_provenance_status": material["provenance_status"],
                        "source_bytes_reused_by_reference": True,
                        "human_qualification_required": True,
                    }
                    result_ids.append(create_item(
                        conn, request, row, "SIRS-", "Finding", "Reported Information",
                        f"Accessed — {material['title']}", detail,
                        "Governed Material", "Not Assessed", material["id"],
                    ))
            else:
                detail = {
                    "record_type": "salintel_source_result", "schema_version": "1.0",
                    "plan_id": plan_item["id"], "task_key": payload.task_key,
                    "authorized_contributor": "Chat Research",
                    "outcome": "No Relevant Result",
                    "source_title": "Governed Material Search",
                    "source_locator": "salcapa://research-adapters/governed-material-search",
                    "notes": "The authorized internal search executed, but no linked governed "
                             "material metadata matched the server-derived terms. This is not a "
                             "finding that information does not exist.",
                    "recorded_by": "SalCAPA Research Executor",
                    "recorded_by_role": "System Research Adapter",
                    "triggered_by": actor(request),
                    "acquired_or_recorded_at": now(),
                    "related_investigation_id": None,
                    "research_execution_id": execution_id,
                    "access_method": "Governed linked-material metadata search",
                    "source_bytes_reused_by_reference": False,
                    "human_qualification_required": True,
                }
                result_ids.append(create_item(
                    conn, request, row, "SIRS-", "Finding", "Unknown",
                    "No Relevant Result — Governed Material Search", detail,
                ))
            execution_detail.update({
                "completed_at": now(), "status": "Completed",
                "matched_material_ids": [int(item["id"]) for item in matches],
                "source_result_ids": result_ids, "match_count": len(matches),
            })
            conn.execute(
                "UPDATE salintel_investigation_items SET detail=?,updated_at=? WHERE id=?",
                (canonical(execution_detail), now(), execution_id),
            )
            conn.execute(
                "UPDATE salintel_investigations SET qualification_status='Unqualified',"
                "updated_by=?,updated_at=? WHERE id=?",
                (actor(request), now(), investigation_id),
            )
            event(conn, request, investigation_id, "SALINTEL_RESEARCH_TOOL_EXECUTED",
                  f"execution_id={execution_id}; adapter={payload.adapter}; "
                  f"task={payload.task_key}; matches={len(matches)}")
            audit(conn, request, "SALINTEL_RESEARCH_TOOL_EXECUTED", execution_id,
                  f"investigation_id={investigation_id}; adapter={payload.adapter}; "
                  f"matches={len(matches)}; external_network=false; cost=false")
            conn.commit()
            return {
                "id": execution_id, "status": "Completed", "adapter": payload.adapter,
                "task_key": payload.task_key, "match_count": len(matches),
                "source_result_ids": result_ids, "external_network_accessed": False,
                "external_cost_incurred": False, "member_visible": False,
            }
        finally:
            conn.close()

    @app.post("/api/salintel/investigations/{investigation_id}/research-plans/{plan_id}/source-results")
    def record_source(investigation_id: int, plan_id: int, payload: RecordSourceResult,
                      request: Request):
        salus(request, "source recording")
        require(request, "write")
        conn = db()
        try:
            row, plan_item, plan = plan_for(conn, investigation_id, plan_id, request)
            if row["status"] in ("Tier Complete", "Closed"):
                raise HTTPException(409, "Completed work cannot be silently reopened")
            task = next((item for item in plan.get("tasks", [])
                         if item.get("task_key") == payload.task_key), None)
            if not task:
                raise HTTPException(422, "Source result must reference an authorized research task")
            contributor = task.get("contributor")
            if payload.outcome not in OUTCOMES.get(contributor, set()):
                raise HTTPException(422, "Source outcome is incompatible with the authorized contributor")
            material = None
            if payload.outcome in REQUIRES_MATERIAL:
                if not payload.source_material_id:
                    raise HTTPException(409, "An accessed or received source requires linked governed material")
                material = linked_material(conn, row, payload.source_material_id, request)
            elif payload.source_material_id:
                raise HTTPException(422, "Unavailable or requested collection cannot claim source material")
            if payload.outcome == "Accessed" and not payload.source_locator.strip():
                raise HTTPException(422, "Chat-accessed research requires a source locator or citation")
            related = None
            if payload.outcome == "Prior SalCAPA Context Reused":
                if not payload.related_investigation_id:
                    raise HTTPException(409, "Prior context reuse requires a governed investigation reference")
                related = investigation(conn, payload.related_investigation_id, request)
                if related["id"] == row["id"]:
                    raise HTTPException(422, "Prior context must reference a different investigation")
            elif payload.related_investigation_id:
                raise HTTPException(422, "A related investigation is allowed only for prior-context reuse")
            detail = {"record_type": "salintel_source_result", "schema_version": "1.0",
                      "plan_id": plan_item["id"], "task_key": payload.task_key,
                      "authorized_contributor": contributor, "outcome": payload.outcome,
                      "source_title": payload.source_title.strip(),
                      "source_locator": payload.source_locator.strip(),
                      "notes": payload.notes.strip(), "recorded_by": actor(request),
                      "recorded_by_role": role(request), "acquired_or_recorded_at": now(),
                      "related_investigation_id": related["id"] if related else None,
                      "source_bytes_reused_by_reference": bool(material),
                      "human_qualification_required": True}
            epistemic = "Reported Information" if payload.outcome in REQUIRES_MATERIAL else "Unknown"
            item_id = create_item(conn, request, row, "SIRS-", "Finding", epistemic,
                                  f"{payload.outcome} — {payload.source_title.strip()}", detail,
                                  payload.source_reliability, payload.information_confidence,
                                  payload.source_material_id)
            conn.execute("UPDATE salintel_investigations SET qualification_status='Unqualified',"
                         "updated_by=?,updated_at=? WHERE id=?",
                         (actor(request), now(), investigation_id))
            event(conn, request, investigation_id, "SALINTEL_RESEARCH_SOURCE_RECORDED",
                  f"source_result_id={item_id}; task={payload.task_key}; outcome={payload.outcome}")
            audit(conn, request, "SALINTEL_RESEARCH_SOURCE_RECORDED", item_id,
                  f"investigation_id={investigation_id}; outcome={payload.outcome}")
            conn.commit()
            return {"id": item_id, "task_key": payload.task_key,
                    "outcome": payload.outcome, "member_visible": False,
                    "qualification_status": "Unqualified"}
        finally:
            conn.close()

    @app.post("/api/salintel/investigations/{investigation_id}/research-plans/{plan_id}/products")
    def create_product(investigation_id: int, plan_id: int, payload: CreateResearchProduct,
                       request: Request):
        salus(request, "synthesis")
        require(request, "write")
        conn = db()
        try:
            row, plan_item, plan = plan_for(conn, investigation_id, plan_id, request)
            view = status_view(conn, row, plan_item, plan)
            if not view["ready_for_synthesis"]:
                raise HTTPException(409, "Every authorized task requires a truthful disposition and Chat must access at least one governed source")
            result_map = {item["id"]: item for item in view["source_results"]}
            normalized_findings = []
            for finding in payload.findings:
                ids = list(dict.fromkeys(finding.source_result_ids))
                if any(item_id not in result_map for item_id in ids):
                    raise HTTPException(422, "Finding citations must reference this research plan's source results")
                if finding.epistemic_state == "Reported Information" and not ids:
                    raise HTTPException(409, "Source-derived reported information requires a source-result citation")
                normalized_findings.append({
                    "statement": finding.statement.strip(),
                    "epistemic_state": finding.epistemic_state,
                    "source_result_ids": ids,
                    "information_confidence": finding.information_confidence.strip() or "Not Assessed",
                    "implications": finding.implications.strip(),
                })
            accessed = [item["id"] for item in view["source_results"]
                        if item["structured_detail"].get("outcome") == "Accessed"]
            unavailable = [item["id"] for item in view["source_results"]
                           if item["structured_detail"].get("outcome") == "Unavailable"]
            collection = [item["id"] for item in view["source_results"]
                          if str(item["structured_detail"].get("outcome", "")).startswith("Requires ")]
            detail = {"record_type": "salintel_research_product", "schema_version": "1.0",
                      "plan_id": plan_id, "plan_version": PLAN_VERSION,
                      "authorized_tier": int(row["authorized_tier"]),
                      "executive_summary": payload.executive_summary.strip(),
                      "findings": normalized_findings,
                      "contradictions": payload.contradictions.strip(),
                      "known_unknowns": payload.known_unknowns.strip(),
                      "implications": payload.implications.strip(),
                      "completion_statement": payload.completion_statement.strip(),
                      "deeper_tier_recommended": payload.deeper_tier_recommended,
                      "deeper_tier_reason": payload.deeper_tier_reason.strip(),
                      "sources_actually_accessed": accessed,
                      "unavailable_source_results": unavailable,
                      "collection_requirements": collection,
                      "review_status": "Awaiting Human Review", "reviewed_by": "",
                      "reviewed_at": "", "review_reason": "",
                      "created_by": actor(request), "created_at": now(),
                      "member_visible": False, "tier_change_authorized": False,
                      "external_escalation_authorized": False}
            item_id = create_item(conn, request, row, "SIPR-", "Finding",
                                  "Reasonable Inference",
                                  f"Tier {row['authorized_tier']} Chat-led research product", detail)
            notification_detail = {
                "record_type": "salintel_research_notification",
                "schema_version": "1.0", "plan_id": plan_id,
                "product_id": item_id,
                "notification_type": "Research Product Awaiting Human Review",
                "delivery_channel": "SalCAPA In-App Review Queue",
                "recipient_scope": "Authorized Salus Personnel",
                "status": "Unread", "delivered_at": now(),
                "acknowledged_by": "", "acknowledged_at": "",
                "acknowledgement_reason": "", "resolved_by": "",
                "resolved_at": "", "resolution_reason": "",
                "member_visible": False, "external_delivery": False,
            }
            notification_id = create_item(
                conn, request, row, "SIN-", "Notification", "Reported Information",
                "Research product awaiting Salus human review", notification_detail,
            )
            conn.execute("UPDATE salintel_investigations SET qualification_status='Unqualified',"
                         "updated_by=?,updated_at=? WHERE id=?",
                         (actor(request), now(), investigation_id))
            event(conn, request, investigation_id, "SALINTEL_RESEARCH_PRODUCT_READY_FOR_REVIEW",
                  f"product_id={item_id}; tier={row['authorized_tier']}; findings={len(normalized_findings)}")
            audit(conn, request, "SALINTEL_RESEARCH_PRODUCT_CREATED", item_id,
                  f"investigation_id={investigation_id}; tier={row['authorized_tier']}")
            event(conn, request, investigation_id,
                  "SALINTEL_RESEARCH_REVIEW_NOTIFICATION_DELIVERED",
                  f"notification_id={notification_id}; product_id={item_id}; channel=in_app")
            audit(conn, request, "SALINTEL_RESEARCH_REVIEW_NOTIFICATION_DELIVERED",
                  notification_id,
                  f"investigation_id={investigation_id}; product_id={item_id}; external=false")
            conn.commit()
            return {"id": item_id, "review_status": "Awaiting Human Review",
                    "notification_id": notification_id,
                    "member_visible": False, "deeper_tier_recommended": payload.deeper_tier_recommended,
                    "tier_change_authorized": False, "external_escalation_authorized": False}
        finally:
            conn.close()

    @app.post("/api/salintel/investigations/{investigation_id}/research-products/{product_id}/review")
    def review_product(investigation_id: int, product_id: int,
                       payload: ReviewResearchProduct, request: Request):
        salus(request, "human product review")
        require(request, "decide")
        conn = db()
        try:
            row = investigation(conn, investigation_id, request)
            item = conn.execute(
                "SELECT * FROM salintel_investigation_items WHERE id=? AND investigation_id=?",
                (product_id, investigation_id),
            ).fetchone()
            if not item or not item["item_key"].startswith("SIPR-"):
                raise HTTPException(404, "SalINTEL research product not found")
            detail = item_detail(item)
            if detail.get("record_type") != "salintel_research_product":
                raise HTTPException(404, "SalINTEL research product not found")
            detail.update({"review_status": payload.status, "reviewed_by": actor(request),
                           "reviewed_at": now(), "review_reason": payload.reason.strip(),
                           "member_visible": False})
            conn.execute("UPDATE salintel_investigation_items SET detail=?,"
                         "epistemic_state=?,member_visible=0,updated_at=? WHERE id=?",
                         (canonical(detail), "Analyst Judgment" if payload.status != "Rejected" else "Hypothesis",
                          now(), product_id))
            for notification in research_items(conn, investigation_id):
                notice = notification["structured_detail"]
                if (notice.get("record_type") != "salintel_research_notification"
                        or int(notice.get("product_id", 0)) != product_id
                        or notice.get("status") == "Resolved"):
                    continue
                notice.update({"status": "Resolved", "resolved_by": actor(request),
                               "resolved_at": now(),
                               "resolution_reason": f"Product review completed: {payload.status}"})
                conn.execute(
                    "UPDATE salintel_investigation_items SET detail=?,updated_at=? WHERE id=?",
                    (canonical(notice), now(), notification["id"]),
                )
            event(conn, request, investigation_id, "SALINTEL_RESEARCH_PRODUCT_REVIEWED",
                  f"product_id={product_id}; status={payload.status}; {payload.reason}")
            audit(conn, request, "SALINTEL_RESEARCH_PRODUCT_REVIEWED", product_id,
                  f"investigation_id={investigation_id}; status={payload.status}")
            conn.commit()
            return {"id": product_id, "review_status": payload.status,
                    "member_visible": False,
                    "investigation_qualification_status": row["qualification_status"]}
        finally:
            conn.close()

    @app.post("/api/salintel/investigations/{investigation_id}/research-notifications/{notification_id}/acknowledge")
    def acknowledge_notification(investigation_id: int, notification_id: int,
                                 payload: AcknowledgeNotification, request: Request):
        salus(request, "review notification acknowledgement")
        require(request, "write")
        conn = db()
        try:
            investigation(conn, investigation_id, request)
            item = conn.execute(
                "SELECT * FROM salintel_investigation_items WHERE id=? AND investigation_id=?",
                (notification_id, investigation_id),
            ).fetchone()
            if not item or not item["item_key"].startswith("SIN-"):
                raise HTTPException(404, "SalINTEL research notification not found")
            detail = item_detail(item)
            if detail.get("record_type") != "salintel_research_notification":
                raise HTTPException(404, "SalINTEL research notification not found")
            if detail.get("status") != "Unread":
                raise HTTPException(409, "Only an unread notification can be acknowledged")
            detail.update({"status": "Acknowledged", "acknowledged_by": actor(request),
                           "acknowledged_at": now(),
                           "acknowledgement_reason": payload.reason.strip()})
            conn.execute(
                "UPDATE salintel_investigation_items SET detail=?,updated_at=? WHERE id=?",
                (canonical(detail), now(), notification_id),
            )
            event(conn, request, investigation_id,
                  "SALINTEL_RESEARCH_REVIEW_NOTIFICATION_ACKNOWLEDGED",
                  f"notification_id={notification_id}; product_id={detail.get('product_id')}")
            audit(conn, request, "SALINTEL_RESEARCH_REVIEW_NOTIFICATION_ACKNOWLEDGED",
                  notification_id, f"investigation_id={investigation_id}")
            conn.commit()
            return {"id": notification_id, "status": "Acknowledged",
                    "member_visible": False, "external_delivery": False}
        finally:
            conn.close()
