#!/usr/bin/env python3
"""Acceptance checks for governed cross-domain SalINTEL relationships."""
import json
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORKSPACE = tempfile.TemporaryDirectory()
os.environ.setdefault("SALUS_DB_BACKEND", "sqlite")
os.environ.setdefault("SALUS_DB_PATH", str(Path(WORKSPACE.name) / "relationships.db"))
os.environ.setdefault("SALUS_BACKUP_DIR", str(Path(WORKSPACE.name) / "backups"))
os.environ.setdefault("SALUS_LOCAL_STORAGE_DIR", str(Path(WORKSPACE.name) / "attachments"))
os.environ.setdefault("SALUS_AUTH_MODE", "prototype")
os.environ.setdefault("SALUS_SEED_DEMO", "1")
sys.path.insert(0, str(ROOT))

from fastapi.testclient import TestClient
import salcapa_runtime
from portable_backup import collect_tenant_records, replace_tenant_records, validate_records

app = salcapa_runtime.core


def create_completed(client, headers, domain, title, subject, engagement):
    created = client.post("/api/salintel/investigations", headers=headers, json={
        "domain_key": domain, "title": title, "subject_reference": subject,
        "purpose": "SYNTHETIC bounded relationship acceptance investigation.",
        "requested_tier": 1, "sensitivity": "Standard",
        "engagement_context": engagement,
    })
    assert created.status_code == 200, created.text
    record_id = created.json()["id"]
    authorized = client.post(
        f"/api/salintel/investigations/{record_id}/authorize-tier", headers=headers,
        json={
            "authorized_tier": 1,
            "scope_statement": "Identity, core dependencies, contradictions, and known unknowns.",
            "checklist_version": "shared-v1", "investigative_lenses": ["Protection"],
            "source_categories": ["authorized synthetic records"],
            "exclusions": ["deep network expansion"],
            "effort_bounds": {"maximum_hours": 2},
            "commercial_treatment": "Included",
            "commercial_reference": "SYNTHETIC-REL-1",
            "reason": "Authorize bounded Tier 1 relationship acceptance work.",
        })
    assert authorized.status_code == 200, authorized.text
    item = client.post(f"/api/salintel/investigations/{record_id}/items",
        headers=headers, json={
            "item_kind": "Finding", "epistemic_state": "Analyst Judgment",
            "title": "SYNTHETIC bounded finding",
            "detail": "Human analyst documented the bounded source review.",
            "source_reliability": "Reliable", "information_confidence": "Moderate",
        })
    assert item.status_code == 200, item.text
    qualified = client.post(f"/api/salintel/investigations/{record_id}/qualify",
        headers=headers, json={"status": "Qualified",
        "reason": "Human reviewer qualified the bounded synthetic record."})
    assert qualified.status_code == 200, qualified.text
    completed = client.post(f"/api/salintel/investigations/{record_id}/complete-tier",
        headers=headers, json={"tier": 1,
        "completion_statement": "Authorized Tier 1 scope is complete.",
        "residual_unknowns": "Deeper network analysis remains out of scope."})
    assert completed.status_code == 200, completed.text
    disclosed = client.post(f"/api/salintel/investigations/{record_id}/disclosure",
        headers=headers, json={"approved_for_tenant": True,
        "reason": "Release the bounded synthetic conclusion."})
    assert disclosed.status_code == 200, disclosed.text
    return record_id


def main():
    client = TestClient(salcapa_runtime.app)
    analyst = {"X-Salus-Tenant": "1", "X-Salus-Role": "Assessment Director",
               "X-Salus-User": "Relationship Analyst",
               "X-Salus-Clearance": "Highly Sensitive"}
    member = {"X-Salus-Tenant": "1", "X-Salus-Role": "Contributor",
              "X-Salus-User": "Protected Member User"}

    source_id = create_completed(client, analyst, "organizations",
        "SYNTHETIC North Organization", "SYNTHETIC-ORG-NORTH", "ENGAGEMENT-A")
    target_id = create_completed(client, analyst, "vendors-suppliers-partners-contractors",
        "SYNTHETIC South Supplier", "SYNTHETIC-VENDOR-SOUTH", "ENGAGEMENT-B")

    types = client.get("/api/salintel/relationship-types/organizations", headers=analyst)
    assert types.status_code == 200, types.text
    assert types.json()["governance_source"] == "salintel_domain_registry"
    relationship_type = "depends_on"
    assert relationship_type in types.json()["relationship_types"]
    assert client.get("/api/salintel/relationship-types/organizations",
                      headers=member).status_code == 403

    material = client.post("/api/materials/upload", headers=analyst, data={
        "title": "SYNTHETIC relationship source", "material_kind": "Document",
        "source_origin": "Authorized synthetic record", "sensitivity": "Sensitive",
        "purpose_tags": json.dumps(["SalINTEL", "Relationships"])},
        files={"file": ("relationship.txt", b"SYNTHETIC RELATIONSHIP SOURCE\n", "text/plain")})
    assert material.status_code == 200, material.text
    material_id = material.json()["id"]
    for state, reason in (("Processing", "Begin governed extraction."),
                          ("Ready for Human Review", "Human source review complete.")):
        response = client.post(f"/api/materials/{material_id}/transition",
                               headers=analyst, json={"status": state, "reason": reason})
        assert response.status_code == 200, response.text
    linked = client.post(f"/api/materials/{material_id}/links", headers=analyst,
        json={"target_type": "salintel_investigation", "target_id": source_id,
              "purpose": "Support the governed cross-domain relationship."})
    assert linked.status_code == 200, linked.text

    forged = client.post(f"/api/salintel/investigations/{source_id}/relationships",
        headers=analyst, json={
            "target_investigation_id": target_id, "relationship_type": relationship_type,
            "rationale": "Attempt to forge review state.", "origin_type": "Chat Suggestion",
            "review_status": "Qualified"})
    assert forged.status_code == 422
    assert client.post(f"/api/salintel/investigations/{source_id}/relationships",
        headers=analyst, json={
            "target_investigation_id": source_id, "relationship_type": relationship_type,
            "rationale": "Self relationship must fail.",
            "origin_type": "Human Analyst"}).status_code == 422
    assert client.post(f"/api/salintel/investigations/{source_id}/relationships",
        headers=analyst, json={
            "target_investigation_id": target_id, "relationship_type": "funds",
            "rationale": "Unconfigured type must fail.",
            "origin_type": "Human Analyst"}).status_code == 422

    count_conn = app.db()
    before_materials = len(collect_tenant_records(count_conn, 1)["materials"])
    count_conn.close()
    created = client.post(f"/api/salintel/investigations/{source_id}/relationships",
        headers=analyst, json={
            "target_investigation_id": target_id, "relationship_type": relationship_type,
            "rationale": "The bounded record indicates a critical supplier dependency.",
            "origin_type": "Chat Suggestion", "source_reliability": "Reliable",
            "information_confidence": "Moderate", "source_material_id": material_id,
            "competing_resource": True})
    assert created.status_code == 200, created.text
    relationship = created.json()
    relationship_id = relationship["id"]
    assert relationship["review_status"] == "Suggested"
    assert relationship["cross_engagement"] is True
    assert relationship["member_visible"] is False
    assert relationship["sensitivity"] == "Sensitive"
    assert client.post(f"/api/salintel/investigations/{source_id}/relationships",
        headers=analyst, json={
            "target_investigation_id": target_id, "relationship_type": relationship_type,
            "rationale": "Duplicate active relationship.",
            "origin_type": "Human Analyst"}).status_code == 409
    assert client.get(f"/api/salintel/investigations/{source_id}/relationships",
                      headers=member).json()["where_used_count"] == 0

    premature = client.post(
        f"/api/salintel/investigations/{source_id}/relationships/{relationship_id}/disclosure",
        headers=analyst, json={"approved_for_tenant": True,
                              "reason": "Unqualified relationship must not release."})
    assert premature.status_code == 409
    review = client.post(
        f"/api/salintel/investigations/{source_id}/relationships/{relationship_id}/review",
        headers=analyst, json={"status": "Qualified",
        "reason": "Human reviewer reconciled the source and both governed records."})
    assert review.status_code == 200 and review.json()["review_status"] == "Qualified"
    assert client.post(
        f"/api/salintel/investigations/{source_id}/relationships/{relationship_id}/review",
        headers=member, json={"status": "Qualified", "reason": "Member forgery."}
    ).status_code == 403
    blocked_source = client.post(
        f"/api/salintel/investigations/{source_id}/relationships/{relationship_id}/disclosure",
        headers=analyst, json={"approved_for_tenant": True,
        "reason": "Source bytes still require independent release."})
    assert blocked_source.status_code == 409
    source_release = client.post(f"/api/materials/{material_id}/disclosure",
        headers=analyst, json={"approved_for_protected_member": True,
        "reason": "Approve the synthetic relationship source for this tenant."})
    assert source_release.status_code == 200, source_release.text
    released = client.post(
        f"/api/salintel/investigations/{source_id}/relationships/{relationship_id}/disclosure",
        headers=analyst, json={"approved_for_tenant": True,
        "reason": "Release the qualified bounded relationship to this tenant."})
    assert released.status_code == 200 and released.json()["member_visible"] is True

    outgoing = client.get(f"/api/salintel/investigations/{source_id}/relationships",
                          headers=analyst).json()
    incoming = client.get(f"/api/salintel/investigations/{target_id}/relationships",
                          headers=analyst).json()
    assert [row["id"] for row in outgoing["outgoing"]] == [relationship_id]
    assert [row["id"] for row in incoming["incoming"]] == [relationship_id]
    member_view = client.get(f"/api/salintel/investigations/{target_id}/relationships",
                             headers=member)
    assert member_view.status_code == 200 and member_view.json()["where_used_count"] == 1
    shown = member_view.json()["incoming"][0]
    for private in ("created_by", "source_reliability", "information_confidence",
                    "source_material_id"):
        assert private not in shown

    searched = client.get("/api/salintel/relationship-search",
        headers=analyst, params={"q": "South Supplier", "relationship_type": relationship_type})
    assert searched.status_code == 200 and searched.json()["result_count"] == 1
    assert client.get("/api/salintel/relationship-search", headers=member).status_code == 403

    conn = app.db()
    records = collect_tenant_records(conn, 1)
    assert not validate_records(records, 1)
    assert len(records["materials"]) == before_materials
    relationship_rows = [row for row in records["salintel_investigation_items"]
                         if str(row.get("item_key", "")).startswith("SIR-")]
    assert len(relationship_rows) == 1
    replace_tenant_records(conn, 1, records)
    conn.commit()
    restored = conn.execute("SELECT detail FROM salintel_investigation_items WHERE id=?",
                            (relationship_id,)).fetchone()
    assert json.loads(restored["detail"])["record_type"] == "salintel_relationship"
    conn.execute("INSERT INTO tenants(id,name,slug,status,created_at) "
                 "VALUES(2,'Other Tenant','other-relationships','Active',?) "
                 "ON CONFLICT(id) DO NOTHING", (app.now(),))
    conn.commit(); conn.close()
    other = {**analyst, "X-Salus-Tenant": "2", "X-Salus-User": "Other Analyst"}
    assert client.get(f"/api/salintel/investigations/{source_id}/relationships",
                      headers=other).status_code == 403

    for record_id in (source_id, target_id):
        events = client.get(f"/api/salintel/investigations/{record_id}",
                            headers=analyst).json()["events"]
        versions = [row["version_no"] for row in events]
        assert versions == list(range(1, len(versions) + 1))
        assert any(row["event_type"] == "SALINTEL_RELATIONSHIP_REVIEWED" for row in events)
    print("SALCAPA_SALINTEL_RELATIONSHIPS_PASS", app.DB_BACKEND)


if __name__ == "__main__":
    main()
