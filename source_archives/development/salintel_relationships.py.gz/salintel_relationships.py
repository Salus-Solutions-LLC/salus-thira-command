"""Governed cross-domain SalINTEL relationship and where-used extension.

Relationships are persisted as typed shared investigative items so source bytes,
tenancy, event history, backup/recovery, and disclosure controls remain unified.
"""
from __future__ import annotations

import json
import uuid
from typing import Literal

from fastapi import HTTPException, Request
from pydantic import BaseModel, ConfigDict, Field, field_validator

Origin = Literal["Human Analyst", "Chat Suggestion", "Source Extraction",
                 "Approved Partner Return"]
ReviewState = Literal["Qualified", "Rejected"]
SENSITIVITY = {"Standard": 0, "Restricted": 1, "Sensitive": 2, "Highly Sensitive": 3}


class CreateRelationship(BaseModel):
    model_config = ConfigDict(extra="forbid")
    target_investigation_id: int = Field(gt=0)
    relationship_type: str = Field(min_length=1, max_length=100)
    rationale: str = Field(min_length=1, max_length=8000)
    origin_type: Origin
    source_reliability: str = Field(default="Not Assessed", max_length=80)
    information_confidence: str = Field(default="Not Assessed", max_length=80)
    source_material_id: int | None = Field(default=None, gt=0)
    effective_from: str = Field(default="", pattern=r"^$|^\d{4}-\d{2}-\d{2}$")
    effective_to: str = Field(default="", pattern=r"^$|^\d{4}-\d{2}-\d{2}$")
    possible_duplicate: bool = False
    competing_resource: bool = False
    source_conflict: bool = False

    @field_validator("relationship_type", "rationale")
    @classmethod
    def clean_required(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("A non-empty value is required.")
        return value


class ReviewRelationship(BaseModel):
    model_config = ConfigDict(extra="forbid")
    status: ReviewState
    reason: str = Field(min_length=1, max_length=4000)


class DiscloseRelationship(BaseModel):
    model_config = ConfigDict(extra="forbid")
    approved_for_tenant: bool
    reason: str = Field(min_length=1, max_length=4000)


def register_salintel_relationships(app, core: dict) -> None:
    db, now = core["db"], core["now"]
    actor, role, tenant_id = core["actor"], core["role"], core["tenant_id"]
    require = core["require"]
    authority = core["require_salus_component_authority"]
    require_sensitivity = core["require_sensitivity"]
    is_member = core["protected_member_request"]
    security_event = core["security_event"]

    def canonical(value):
        return json.dumps(value, sort_keys=True, separators=(",", ":"),
                          ensure_ascii=False, default=str)

    def salus(request: Request, action: str):
        require(request, "read")
        authority(request, f"SalINTEL relationship {action}")

    def investigation(conn, record_id: int, request: Request):
        row = conn.execute(
            "SELECT * FROM salintel_investigations WHERE id=?", (record_id,)
        ).fetchone()
        if not row:
            raise HTTPException(404, "SalINTEL investigation not found")
        if int(row["tenant_id"]) != tenant_id(request):
            security_event(request, "SALINTEL_RELATIONSHIP_TENANT_BOUNDARY_VIOLATION",
                           "High", f"investigation_id={record_id}")
            raise HTTPException(403, "Tenant boundary violation")
        require_sensitivity(request, row["sensitivity"])
        return row

    def parse_detail(item):
        try:
            value = json.loads(item["detail"])
            return value if isinstance(value, dict) else {}
        except (TypeError, ValueError, json.JSONDecodeError):
            return {}

    def relationship_items(conn, tenant: int):
        rows = []
        for row in conn.execute(
            "SELECT * FROM salintel_investigation_items "
            "WHERE tenant_id=? AND item_key LIKE 'SIR-%' ORDER BY id", (tenant,)
        ):
            item = dict(row)
            item["structured_detail"] = parse_detail(item)
            if item["structured_detail"].get("record_type") == "salintel_relationship":
                rows.append(item)
        return rows

    def event(conn, request: Request, record_id: int, event_type: str, reason: str):
        row = conn.execute(
            "SELECT * FROM salintel_investigations WHERE id=?", (record_id,)
        ).fetchone()
        version = int(conn.execute(
            "SELECT COUNT(*) c FROM salintel_investigation_events WHERE investigation_id=?",
            (record_id,),
        ).fetchone()["c"]) + 1
        conn.execute(
            "INSERT INTO salintel_investigation_events(tenant_id,investigation_id,version_no,"
            "event_type,reason,snapshot_json,changed_by,changed_by_role,created_at) "
            "VALUES(?,?,?,?,?,?,?,?,?)",
            (row["tenant_id"], record_id, version, event_type, reason[:4000],
             canonical(dict(row)), actor(request), role(request), now()),
        )

    def audit(conn, request: Request, action: str, item_id: int, detail: str):
        conn.execute(
            "INSERT INTO audit_log(ts,user_name,action,entity_type,entity_id,detail,tenant_id) "
            "VALUES(?,?,?,?,?,?,?)",
            (now(), actor(request), action, "salintel_relationship", item_id,
             detail[:2000], tenant_id(request)),
        )

    def linked_material(conn, source_id: int, material_id: int, request: Request):
        row = conn.execute(
            "SELECT m.* FROM material_links l JOIN materials m ON m.id=l.material_id "
            "WHERE l.tenant_id=? AND l.material_id=? "
            "AND l.target_type='salintel_investigation' AND l.target_id=?",
            (tenant_id(request), material_id, source_id),
        ).fetchone()
        if not row:
            raise HTTPException(409, "Source material must be governed and linked to the source investigation")
        require_sensitivity(request, row["sensitivity"])
        return row

    def allowed_types(conn, domain_key: str):
        row = conn.execute(
            "SELECT allowed_relationships_json FROM salintel_domains WHERE domain_key=?",
            (domain_key,),
        ).fetchone()
        try:
            values = json.loads(row["allowed_relationships_json"]) if row else []
        except (TypeError, ValueError, json.JSONDecodeError):
            values = []
        return sorted({str(value).strip() for value in values if str(value).strip()})

    def relationship_view(conn, item):
        detail = item["structured_detail"]
        source = conn.execute(
            "SELECT id,record_key,domain_key,title,subject_reference,status,sensitivity,"
            "qualification_status,disclosure_status,completed_tier,engagement_context "
            "FROM salintel_investigations WHERE id=?", (item["investigation_id"],)
        ).fetchone()
        target = conn.execute(
            "SELECT id,record_key,domain_key,title,subject_reference,status,sensitivity,"
            "qualification_status,disclosure_status,completed_tier,engagement_context "
            "FROM salintel_investigations WHERE id=?", (detail.get("target_investigation_id"),)
        ).fetchone()
        return {
            "id": item["id"], "item_key": item["item_key"],
            "relationship_type": detail.get("relationship_type", ""),
            "direction": "outgoing", "source": dict(source) if source else None,
            "target": dict(target) if target else None,
            "rationale": detail.get("rationale", ""),
            "origin_type": detail.get("origin_type", ""),
            "review_status": detail.get("review_status", "Suggested"),
            "effective_from": detail.get("effective_from", ""),
            "effective_to": detail.get("effective_to", ""),
            "sensitivity": detail.get("sensitivity", "Restricted"),
            "possible_duplicate": bool(detail.get("possible_duplicate")),
            "competing_resource": bool(detail.get("competing_resource")),
            "source_conflict": bool(detail.get("source_conflict")),
            "cross_engagement": bool(detail.get("cross_engagement")),
            "source_reliability": item["source_reliability"],
            "information_confidence": item["information_confidence"],
            "source_material_id": item["source_material_id"],
            "member_visible": bool(item["member_visible"]),
            "created_by": item["created_by"], "created_at": item["created_at"],
            "updated_at": item["updated_at"],
        }

    def item_for_source(conn, source_id: int, item_id: int, request: Request):
        source = investigation(conn, source_id, request)
        item = conn.execute(
            "SELECT * FROM salintel_investigation_items WHERE id=? AND investigation_id=?",
            (item_id, source_id),
        ).fetchone()
        if not item or not item["item_key"].startswith("SIR-"):
            raise HTTPException(404, "SalINTEL relationship not found")
        value = dict(item)
        value["structured_detail"] = parse_detail(item)
        if value["structured_detail"].get("record_type") != "salintel_relationship":
            raise HTTPException(404, "SalINTEL relationship not found")
        return source, value

    @app.get("/api/salintel/relationship-types/{domain_key}")
    def types(domain_key: str, request: Request):
        salus(request, "type review")
        conn = db()
        try:
            values = allowed_types(conn, domain_key)
            if not values:
                raise HTTPException(404, "Investigative domain or relationship policy not found")
            return {"domain_key": domain_key, "relationship_types": values,
                    "governance_source": "salintel_domain_registry"}
        finally:
            conn.close()

    @app.post("/api/salintel/investigations/{source_id}/relationships")
    def create(source_id: int, payload: CreateRelationship, request: Request):
        salus(request, "creation")
        require(request, "write")
        if source_id == payload.target_investigation_id:
            raise HTTPException(422, "A relationship must connect two distinct investigations")
        conn = db()
        try:
            source = investigation(conn, source_id, request)
            target = investigation(conn, payload.target_investigation_id, request)
            configured = allowed_types(conn, source["domain_key"])
            if payload.relationship_type not in configured:
                raise HTTPException(422, "Relationship type is not authorized by the source domain registry")
            material = None
            if payload.source_material_id:
                material = linked_material(conn, source_id, payload.source_material_id, request)
            for existing in relationship_items(conn, tenant_id(request)):
                detail = existing["structured_detail"]
                if (int(existing["investigation_id"]) == source_id
                        and int(detail.get("target_investigation_id", 0)) == payload.target_investigation_id
                        and detail.get("relationship_type") == payload.relationship_type
                        and detail.get("review_status") != "Rejected"):
                    raise HTTPException(409, "An active relationship of this type already exists")
            sensitivity_values = [source["sensitivity"], target["sensitivity"]]
            if material:
                sensitivity_values.append(material["sensitivity"])
            sensitivity = max(sensitivity_values, key=lambda value: SENSITIVITY.get(value, 1))
            cross_engagement = bool(
                source["engagement_context"] and target["engagement_context"]
                and source["engagement_context"] != target["engagement_context"]
            )
            detail = {
                "record_type": "salintel_relationship", "schema_version": "1.0",
                "source_investigation_id": source_id,
                "target_investigation_id": payload.target_investigation_id,
                "relationship_type": payload.relationship_type,
                "rationale": payload.rationale.strip(), "origin_type": payload.origin_type,
                "review_status": "Suggested", "reviewed_by": "", "reviewed_at": "",
                "review_reason": "", "disclosure_status": "Salus Internal",
                "disclosed_by": "", "disclosed_at": "", "disclosure_reason": "",
                "effective_from": payload.effective_from, "effective_to": payload.effective_to,
                "sensitivity": sensitivity, "possible_duplicate": payload.possible_duplicate,
                "competing_resource": payload.competing_resource,
                "source_conflict": payload.source_conflict,
                "cross_engagement": cross_engagement,
            }
            epistemic = "Hypothesis" if payload.origin_type == "Chat Suggestion" else (
                "Reported Information" if payload.origin_type in
                ("Source Extraction", "Approved Partner Return") else "Analyst Judgment"
            )
            ts = now()
            cur = conn.execute(
                "INSERT INTO salintel_investigation_items(tenant_id,investigation_id,item_key,"
                "item_kind,epistemic_state,title,detail,source_reliability,"
                "information_confidence,source_material_id,member_visible,created_by,"
                "created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (source["tenant_id"], source_id, "SIR-" + uuid.uuid4().hex, "Finding",
                 epistemic, f"{payload.relationship_type}: {source['title']} → {target['title']}",
                 canonical(detail), payload.source_reliability.strip() or "Not Assessed",
                 payload.information_confidence.strip() or "Not Assessed",
                 payload.source_material_id, 0, actor(request), ts, ts),
            )
            item_id = int(cur.lastrowid)
            reason = f"relationship_id={item_id}; type={payload.relationship_type}; status=Suggested"
            event(conn, request, source_id, "SALINTEL_RELATIONSHIP_SUGGESTED", reason)
            event(conn, request, payload.target_investigation_id,
                  "SALINTEL_RELATIONSHIP_INCOMING", reason)
            audit(conn, request, "SALINTEL_RELATIONSHIP_CREATED", item_id, reason)
            conn.commit()
            item = conn.execute(
                "SELECT * FROM salintel_investigation_items WHERE id=?", (item_id,)
            ).fetchone()
            value = dict(item); value["structured_detail"] = parse_detail(item)
            return relationship_view(conn, value)
        finally:
            conn.close()

    @app.post("/api/salintel/investigations/{source_id}/relationships/{item_id}/review")
    def review(source_id: int, item_id: int, payload: ReviewRelationship, request: Request):
        salus(request, "human review")
        require(request, "decide")
        conn = db()
        try:
            source, item = item_for_source(conn, source_id, item_id, request)
            detail = item["structured_detail"]
            target_id = int(detail["target_investigation_id"])
            investigation(conn, target_id, request)
            detail.update({"review_status": payload.status, "reviewed_by": actor(request),
                           "reviewed_at": now(), "review_reason": payload.reason.strip(),
                           "disclosure_status": "Salus Internal", "disclosed_by": "",
                           "disclosed_at": "", "disclosure_reason": ""})
            conn.execute(
                "UPDATE salintel_investigation_items SET epistemic_state=?,detail=?,"
                "member_visible=0,updated_at=? WHERE id=?",
                ("Analyst Judgment" if payload.status == "Qualified" else "Hypothesis",
                 canonical(detail), now(), item_id),
            )
            reason = f"relationship_id={item_id}; status={payload.status}; {payload.reason}"
            event(conn, request, source_id, "SALINTEL_RELATIONSHIP_REVIEWED", reason)
            event(conn, request, target_id, "SALINTEL_RELATIONSHIP_REVIEWED", reason)
            audit(conn, request, "SALINTEL_RELATIONSHIP_REVIEWED", item_id, reason)
            conn.commit()
            item = conn.execute(
                "SELECT * FROM salintel_investigation_items WHERE id=?", (item_id,)
            ).fetchone()
            value = dict(item); value["structured_detail"] = parse_detail(item)
            return relationship_view(conn, value)
        finally:
            conn.close()

    @app.post("/api/salintel/investigations/{source_id}/relationships/{item_id}/disclosure")
    def disclose(source_id: int, item_id: int, payload: DiscloseRelationship, request: Request):
        salus(request, "disclosure decision")
        require(request, "decide")
        conn = db()
        try:
            source, item = item_for_source(conn, source_id, item_id, request)
            detail = item["structured_detail"]
            target_id = int(detail["target_investigation_id"])
            target = investigation(conn, target_id, request)
            if payload.approved_for_tenant:
                if detail.get("review_status") != "Qualified":
                    raise HTTPException(409, "Relationship disclosure requires human qualification")
                for record in (source, target):
                    if (record["qualification_status"] != "Qualified"
                            or int(record["completed_tier"]) == 0
                            or record["disclosure_status"] != "Approved for Tenant"):
                        raise HTTPException(
                            409, "Both related investigations require qualified completed disclosure"
                        )
                if item["source_material_id"] not in (None, ""):
                    material = conn.execute(
                        "SELECT disclosure_status FROM materials WHERE id=? AND tenant_id=?",
                        (item["source_material_id"], tenant_id(request)),
                    ).fetchone()
                    if not material or material["disclosure_status"] != "Approved for Tenant":
                        raise HTTPException(409, "Relationship source requires independent disclosure approval")
            approved = bool(payload.approved_for_tenant)
            detail.update({
                "disclosure_status": "Approved for Tenant" if approved else "Salus Internal",
                "disclosed_by": actor(request) if approved else "",
                "disclosed_at": now() if approved else "",
                "disclosure_reason": payload.reason.strip(),
            })
            conn.execute(
                "UPDATE salintel_investigation_items SET detail=?,member_visible=?,updated_at=? WHERE id=?",
                (canonical(detail), 1 if approved else 0, now(), item_id),
            )
            reason = f"relationship_id={item_id}; approved={approved}; {payload.reason}"
            event(conn, request, source_id, "SALINTEL_RELATIONSHIP_DISCLOSURE", reason)
            event(conn, request, target_id, "SALINTEL_RELATIONSHIP_DISCLOSURE", reason)
            audit(conn, request, "SALINTEL_RELATIONSHIP_DISCLOSURE", item_id, reason)
            conn.commit()
            item = conn.execute(
                "SELECT * FROM salintel_investigation_items WHERE id=?", (item_id,)
            ).fetchone()
            value = dict(item); value["structured_detail"] = parse_detail(item)
            return relationship_view(conn, value)
        finally:
            conn.close()

    @app.get("/api/salintel/investigations/{record_id}/relationships")
    def where_used(record_id: int, request: Request):
        require(request, "read")
        conn = db()
        try:
            record = conn.execute(
                "SELECT * FROM salintel_investigations WHERE id=?", (record_id,)
            ).fetchone()
            if not record:
                raise HTTPException(404, "SalINTEL investigation not found")
            if int(record["tenant_id"]) != tenant_id(request):
                raise HTTPException(403, "Tenant boundary violation")
            member = is_member(request)
            if member:
                if record["disclosure_status"] != "Approved for Tenant":
                    raise HTTPException(404, "Released SalINTEL investigation not found")
            else:
                authority(request, "SalINTEL relationship review")
                require_sensitivity(request, record["sensitivity"])
            outgoing, incoming = [], []
            for item in relationship_items(conn, tenant_id(request)):
                detail = item["structured_detail"]
                source_id = int(item["investigation_id"])
                target_id = int(detail.get("target_investigation_id", 0))
                if record_id not in (source_id, target_id):
                    continue
                view = relationship_view(conn, item)
                source, target = view["source"], view["target"]
                if not source or not target:
                    continue
                if member:
                    if (not view["member_visible"]
                            or source["disclosure_status"] != "Approved for Tenant"
                            or target["disclosure_status"] != "Approved for Tenant"):
                        continue
                    for protected in ("created_by", "source_reliability",
                                      "information_confidence", "source_material_id"):
                        view.pop(protected, None)
                    for related in (source, target):
                        related.pop("engagement_context", None)
                else:
                    require_sensitivity(request, source["sensitivity"])
                    require_sensitivity(request, target["sensitivity"])
                if record_id == source_id:
                    outgoing.append(view)
                else:
                    view["direction"] = "incoming"
                    incoming.append(view)
            return {"investigation_id": record_id, "outgoing": outgoing,
                    "incoming": incoming, "where_used_count": len(outgoing) + len(incoming)}
        finally:
            conn.close()

    @app.get("/api/salintel/relationship-search")
    def search(request: Request, q: str = "", relationship_type: str = "",
               domain_key: str = "", limit: int = 100):
        salus(request, "enterprise search")
        query = q.strip().lower()
        conn = db()
        try:
            results = []
            for item in reversed(relationship_items(conn, tenant_id(request))):
                view = relationship_view(conn, item)
                source, target = view["source"], view["target"]
                if not source or not target:
                    continue
                try:
                    require_sensitivity(request, source["sensitivity"])
                    require_sensitivity(request, target["sensitivity"])
                except HTTPException:
                    continue
                if relationship_type and view["relationship_type"] != relationship_type:
                    continue
                if domain_key and domain_key not in (source["domain_key"], target["domain_key"]):
                    continue
                haystack = " ".join([
                    view["relationship_type"], view["rationale"], source["title"],
                    source["subject_reference"], target["title"], target["subject_reference"],
                ]).lower()
                if query and query not in haystack:
                    continue
                results.append(view)
                if len(results) >= max(1, min(limit, 200)):
                    break
            return {"query": q, "relationship_type": relationship_type,
                    "domain_key": domain_key, "results": results,
                    "result_count": len(results)}
        finally:
            conn.close()
