"""Governed recurring-monitoring profiles for every SalINTEL domain.

Monitoring is deliberately independent from investigation depth.  Every request,
approval, pause, resume, and end is an append-only profile version; none of these
actions reopens an investigation, changes tier, creates a charge, releases a result,
or authorizes an external party.
"""
from __future__ import annotations

import calendar
import json
import re
import uuid
from datetime import date, datetime, timedelta
from typing import Literal

from fastapi import HTTPException, Request
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

Selection = Literal["No", "Yes"]
Cadence = Literal["Daily", "Weekly", "Monthly", "Quarterly", "Custom"]
Commercial = Literal["Not Determined", "Included", "Bundled", "Separate Proposal", "Waived"]
Transition = Literal["Pause", "Resume", "End", "Cancel"]
MonitoringOutcome = Literal[
    "No Material Change", "New Information", "Material Change",
    "Escalation / Immediate Attention",
]
MonitoringReviewDecision = Literal["Qualified", "Return for Supplement", "Rejected"]
ACTIVE_STATES = {"Awaiting Salus Approval", "Active", "Paused"}


class MonitoringSelection(BaseModel):
    model_config = ConfigDict(extra="forbid")
    recurring_monitoring: Selection = "No"
    purpose: str = Field(default="", max_length=4000)
    requested_scope: str = Field(default="", max_length=8000)
    requested_cadence: Cadence | None = None
    requested_start_date: str = Field(default="", max_length=40)
    requested_end_date: str = Field(default="", max_length=40)
    requested_renewal_date: str = Field(default="", max_length=40)
    source_categories: list[str] = Field(default_factory=list, max_length=100)
    exclusions: list[str] = Field(default_factory=list, max_length=100)
    questions: list[str] = Field(default_factory=list, max_length=200)
    known_unknowns: list[str] = Field(default_factory=list, max_length=200)
    indicators: list[str] = Field(default_factory=list, max_length=200)
    watch_terms: list[str] = Field(default_factory=list, max_length=200)
    entities: list[str] = Field(default_factory=list, max_length=200)
    relationships: list[str] = Field(default_factory=list, max_length=200)
    dependencies: list[str] = Field(default_factory=list, max_length=200)
    geographic_bounds: str = Field(default="", max_length=4000)
    jurisdiction_bounds: str = Field(default="", max_length=4000)
    language_bounds: str = Field(default="", max_length=1000)
    change_thresholds: str = Field(default="", max_length=8000)
    escalation_criteria: str = Field(default="", max_length=8000)
    partner_support_requested: bool = False
    commercial_preference: Commercial = "Not Determined"

    @field_validator("recurring_monitoring", mode="before")
    @classmethod
    def null_is_no(cls, value):
        return "No" if value is None or value == "" else value

    @field_validator(
        "purpose", "requested_scope", "requested_start_date", "requested_end_date",
        "requested_renewal_date", "geographic_bounds", "jurisdiction_bounds",
        "language_bounds", "change_thresholds", "escalation_criteria",
    )
    @classmethod
    def clean_text(cls, value: str) -> str:
        return value.strip()

    @field_validator(
        "source_categories", "exclusions", "questions", "known_unknowns",
        "indicators", "watch_terms", "entities", "relationships", "dependencies",
    )
    @classmethod
    def clean_list(cls, value: list[str]) -> list[str]:
        result = list(dict.fromkeys(str(item).strip() for item in value if str(item).strip()))
        if any(len(item) > 1000 for item in result):
            raise ValueError("Monitoring list entries may not exceed 1000 characters")
        return result

    @model_validator(mode="after")
    def require_affirmative_scope(self):
        if self.recurring_monitoring == "Yes":
            if not self.purpose or not self.requested_scope or self.requested_cadence is None:
                raise ValueError("A Yes selection requires purpose, requested scope, and cadence")
        return self


class ApproveMonitoring(BaseModel):
    model_config = ConfigDict(extra="forbid")
    approved_scope: str = Field(min_length=1, max_length=8000)
    cadence: Cadence
    cadence_detail: str = Field(default="", max_length=1000)
    start_date: str = Field(min_length=1, max_length=40)
    end_date: str = Field(default="", max_length=40)
    renewal_date: str = Field(default="", max_length=40)
    approved_sources: list[str] = Field(min_length=1, max_length=100)
    exclusions: list[str] = Field(default_factory=list, max_length=100)
    questions: list[str] = Field(default_factory=list, max_length=200)
    known_unknowns: list[str] = Field(default_factory=list, max_length=200)
    indicators: list[str] = Field(default_factory=list, max_length=200)
    watch_terms: list[str] = Field(default_factory=list, max_length=200)
    entities: list[str] = Field(default_factory=list, max_length=200)
    relationships: list[str] = Field(default_factory=list, max_length=200)
    dependencies: list[str] = Field(default_factory=list, max_length=200)
    geographic_bounds: str = Field(default="", max_length=4000)
    jurisdiction_bounds: str = Field(default="", max_length=4000)
    language_bounds: str = Field(default="", max_length=1000)
    change_thresholds: str = Field(min_length=1, max_length=8000)
    escalation_criteria: str = Field(min_length=1, max_length=8000)
    review_requirements: str = Field(min_length=1, max_length=4000)
    member_notification_policy: str = Field(min_length=1, max_length=4000)
    member_release_permitted: bool = False
    global_partner_eligible: bool = False
    commercial_treatment: Commercial
    commercial_reference: str = Field(default="", max_length=500)
    approval_reason: str = Field(min_length=1, max_length=4000)

    @field_validator(
        "approved_scope", "cadence_detail", "start_date", "end_date", "renewal_date",
        "geographic_bounds", "jurisdiction_bounds", "language_bounds", "change_thresholds",
        "escalation_criteria", "review_requirements", "member_notification_policy",
        "commercial_reference", "approval_reason",
    )
    @classmethod
    def clean_text(cls, value: str) -> str:
        result = value.strip()
        return result

    @field_validator(
        "approved_sources", "exclusions", "questions", "known_unknowns", "indicators",
        "watch_terms", "entities", "relationships", "dependencies",
    )
    @classmethod
    def clean_list(cls, value: list[str]) -> list[str]:
        result = list(dict.fromkeys(str(item).strip() for item in value if str(item).strip()))
        if any(len(item) > 1000 for item in result):
            raise ValueError("Monitoring list entries may not exceed 1000 characters")
        return result


class MonitoringTransition(BaseModel):
    model_config = ConfigDict(extra="forbid")
    action: Transition
    reason: str = Field(min_length=1, max_length=4000)

    @field_validator("reason")
    @classmethod
    def clean_reason(cls, value: str) -> str:
        result = value.strip()
        if not result:
            raise ValueError("A reason is required")
        return result


class ExecuteMonitoringCycle(BaseModel):
    model_config = ConfigDict(extra="forbid")
    reason: str = Field(min_length=1, max_length=4000)
    execute_before_due: bool = False

    @field_validator("reason")
    @classmethod
    def clean_reason(cls, value: str) -> str:
        result = value.strip()
        if not result:
            raise ValueError("An execution authorization reason is required")
        return result


class MonitoringFinding(BaseModel):
    model_config = ConfigDict(extra="forbid")
    statement: str = Field(min_length=1, max_length=8000)
    epistemic_state: Literal[
        "Reported Information", "Inference", "Analyst Judgment", "Hypothesis",
        "Contradiction", "Information Gap", "Unknown",
    ]
    material_ids: list[int] = Field(default_factory=list, max_length=100)

    @field_validator("statement")
    @classmethod
    def clean_statement(cls, value: str) -> str:
        return value.strip()


class RecordMonitoringOutcome(BaseModel):
    model_config = ConfigDict(extra="forbid")
    outcome: MonitoringOutcome
    narrative: str = Field(min_length=1, max_length=16000)
    findings: list[MonitoringFinding] = Field(default_factory=list, max_length=200)
    corroboration: list[str] = Field(default_factory=list, max_length=200)
    contradictions: list[str] = Field(default_factory=list, max_length=200)
    new_known_unknowns: list[str] = Field(default_factory=list, max_length=200)
    resolved_known_unknowns: list[str] = Field(default_factory=list, max_length=200)
    changed_relationships: list[str] = Field(default_factory=list, max_length=200)
    changed_dependencies: list[str] = Field(default_factory=list, max_length=200)
    weak_signals: list[str] = Field(default_factory=list, max_length=200)
    anomalies: list[str] = Field(default_factory=list, max_length=200)
    implications: list[str] = Field(default_factory=list, max_length=200)
    evidence_material_ids: list[int] = Field(default_factory=list, max_length=100)
    recommend_new_investigation: bool = False
    recommend_deeper_tier: bool = False

    @field_validator("narrative")
    @classmethod
    def clean_narrative(cls, value: str) -> str:
        return value.strip()

    @field_validator(
        "corroboration", "contradictions", "new_known_unknowns",
        "resolved_known_unknowns", "changed_relationships", "changed_dependencies",
        "weak_signals", "anomalies", "implications",
    )
    @classmethod
    def clean_lists(cls, value: list[str]) -> list[str]:
        result = list(dict.fromkeys(str(item).strip() for item in value if str(item).strip()))
        if any(len(item) > 2000 for item in result):
            raise ValueError("Monitoring analysis entries may not exceed 2000 characters")
        return result


class ReviewMonitoringOutcome(BaseModel):
    model_config = ConfigDict(extra="forbid")
    decision: MonitoringReviewDecision
    reason: str = Field(min_length=1, max_length=8000)

    @field_validator("reason")
    @classmethod
    def clean_reason(cls, value: str) -> str:
        result = value.strip()
        if not result:
            raise ValueError("A human-review reason is required")
        return result


class AcknowledgeMonitoringNotification(BaseModel):
    model_config = ConfigDict(extra="forbid")
    reason: str = Field(min_length=1, max_length=4000)

    @field_validator("reason")
    @classmethod
    def clean_reason(cls, value: str) -> str:
        result = value.strip()
        if not result:
            raise ValueError("An acknowledgement reason is required")
        return result


def register_salintel_monitoring(app, core: dict) -> None:
    db, now = core["db"], core["now"]
    actor, role, tenant_id = core["actor"], core["role"], core["tenant_id"]
    require = core["require"]
    authority = core["require_salus_component_authority"]
    require_sensitivity = core["require_sensitivity"]
    is_member = core["protected_member_request"]
    security_event = core["security_event"]

    def canonical(value):
        return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str)

    def parsed(value, fallback):
        try:
            result = json.loads(value)
            return result
        except (TypeError, ValueError, json.JSONDecodeError):
            return fallback

    def item_detail(item):
        value = parsed(item["detail"], {})
        return value if isinstance(value, dict) else {}

    def investigation(conn, investigation_id: int, request: Request):
        row = conn.execute(
            "SELECT * FROM salintel_investigations WHERE id=?", (investigation_id,)
        ).fetchone()
        if not row:
            raise HTTPException(404, "SalINTEL investigation not found")
        if int(row["tenant_id"]) != tenant_id(request):
            security_event(request, "SALINTEL_MONITORING_TENANT_BOUNDARY_VIOLATION", "High",
                           f"investigation_id={investigation_id}")
            raise HTTPException(403, "Tenant boundary violation")
        require_sensitivity(request, row["sensitivity"])
        if is_member(request) and row["disclosure_status"] != "Approved for Tenant":
            raise HTTPException(403, "Investigation is not approved for Protected Member access")
        return row

    def records(conn, investigation_id: int, record_type: str):
        result = []
        for item in conn.execute(
            "SELECT * FROM salintel_investigation_items WHERE investigation_id=? ORDER BY id",
            (investigation_id,),
        ):
            value = item_detail(item)
            if value.get("record_type") == record_type:
                result.append({"id": item["id"], "item_key": item["item_key"],
                               "created_at": item["created_at"],
                               "source_material_id": item["source_material_id"], **value})
        return result

    def versions(conn, investigation_id: int):
        return records(conn, investigation_id, "salintel_monitoring_profile")

    def latest_profiles(conn, investigation_id: int):
        latest = {}
        for value in versions(conn, investigation_id):
            key = value["profile_key"]
            if key not in latest or int(value["version_no"]) > int(latest[key]["version_no"]):
                latest[key] = value
        return list(latest.values())

    def current_profile(conn, investigation_id: int, profile_key: str):
        found = [value for value in versions(conn, investigation_id)
                 if value["profile_key"] == profile_key]
        if not found:
            raise HTTPException(404, "Monitoring profile not found")
        return max(found, key=lambda value: int(value["version_no"]))

    def insert_record(conn, request: Request, row, value: dict, *, prefix="SIMP-",
                      kind="Collection Requirement", epistemic="Unknown",
                      title="Recurring monitoring profile", source_material_id=None):
        stamp = now()
        item_key = prefix + uuid.uuid4().hex[:12].upper()
        conn.execute(
            "INSERT INTO salintel_investigation_items(tenant_id,investigation_id,item_key,"
            "item_kind,epistemic_state,title,detail,source_reliability,information_confidence,"
            "source_material_id,member_visible,created_by,created_at,updated_at) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (row["tenant_id"], row["id"], item_key, kind, epistemic,
             title, canonical(value), "Not Assessed", "Not Assessed",
             source_material_id, 0, actor(request), stamp, stamp),
        )
        return int(conn.execute(
            "SELECT id FROM salintel_investigation_items WHERE item_key=?", (item_key,)
        ).fetchone()["id"])

    def insert_version(conn, request: Request, row, value: dict):
        return insert_record(conn, request, row, value)

    def monitoring_terms(row, profile):
        values = [row["subject_reference"], row["title"], profile.get("approved_scope", "")]
        for field in ("questions", "known_unknowns", "indicators", "watch_terms",
                      "entities", "relationships", "dependencies"):
            values.extend(profile.get(field, []) or [])
        stop = {"about", "against", "approved", "change", "changes", "from", "monitor",
                "monitoring", "source", "sources", "that", "their", "this", "with"}
        terms = []
        for value in values:
            for term in re.findall(r"[A-Za-z0-9][A-Za-z0-9_-]{2,}", str(value).lower()):
                if term not in stop and term not in terms:
                    terms.append(term)
        return terms[:40]

    def add_months(value: date, months: int):
        target = value.month - 1 + months
        year, month = value.year + target // 12, target % 12 + 1
        return date(year, month, min(value.day, calendar.monthrange(year, month)[1]))

    def next_research_date(cadence: str, completed_at: str):
        try:
            current = datetime.fromisoformat(completed_at.replace("Z", "+00:00")).date()
        except (TypeError, ValueError):
            current = date.today()
        if cadence == "Daily":
            return str(current + timedelta(days=1))
        if cadence == "Weekly":
            return str(current + timedelta(days=7))
        if cadence == "Monthly":
            return str(add_months(current, 1))
        if cadence == "Quarterly":
            return str(add_months(current, 3))
        return "Salus scheduled custom cadence"

    def execution(conn, investigation_id: int, profile_key: str, execution_id: int):
        found = [item for item in records(conn, investigation_id, "salintel_monitoring_cycle_execution")
                 if item["id"] == execution_id and item.get("profile_key") == profile_key]
        if not found:
            raise HTTPException(404, "Monitoring cycle execution not found")
        return found[0]

    def event(conn, request: Request, row, event_type: str, reason: str):
        version = int(conn.execute(
            "SELECT COUNT(*) c FROM salintel_investigation_events WHERE investigation_id=?",
            (row["id"],),
        ).fetchone()["c"]) + 1
        snapshot = conn.execute(
            "SELECT * FROM salintel_investigations WHERE id=?", (row["id"],)
        ).fetchone()
        conn.execute(
            "INSERT INTO salintel_investigation_events(tenant_id,investigation_id,version_no,"
            "event_type,reason,snapshot_json,changed_by,changed_by_role,created_at) "
            "VALUES(?,?,?,?,?,?,?,?,?)",
            (row["tenant_id"], row["id"], version, event_type, reason[:4000],
             canonical(dict(snapshot)), actor(request), role(request), now()),
        )

    def audit(conn, request: Request, action: str, entity_id: int, detail: str):
        conn.execute(
            "INSERT INTO audit_log(ts,user_name,action,entity_type,entity_id,detail,tenant_id) "
            "VALUES(?,?,?,?,?,?,?)",
            (now(), actor(request), action, "salintel_monitoring_profile", entity_id,
             detail[:2000], tenant_id(request)),
        )

    def member_view(value):
        allowed = {
            "profile_key", "version_no", "explicit_selection", "status", "purpose",
            "requested_scope", "requested_cadence", "requested_start_date",
            "requested_end_date", "requested_renewal_date", "baseline_tier_reference",
            "requested_by", "requested_at", "approved_scope", "cadence", "cadence_detail",
            "start_date", "end_date", "renewal_date", "member_notification_policy",
            "member_release_permitted", "approved_at", "lifecycle_action", "lifecycle_at",
            "created_at",
        }
        return {key: value[key] for key in allowed if key in value}

    @app.get("/api/salintel/investigations/{investigation_id}/monitoring")
    def list_monitoring(investigation_id: int, request: Request):
        require(request, "read")
        conn = db()
        row = investigation(conn, investigation_id, request)
        all_versions = versions(conn, row["id"])
        current = latest_profiles(conn, row["id"])
        executions = records(conn, row["id"], "salintel_monitoring_cycle_execution")
        outcomes = records(conn, row["id"], "salintel_monitoring_cycle_outcome")
        notifications = records(conn, row["id"], "salintel_monitoring_notification")
        reviews = records(conn, row["id"], "salintel_monitoring_outcome_review")
        acknowledgements = records(
            conn, row["id"], "salintel_monitoring_notification_acknowledgement"
        )
        if is_member(request):
            name = actor(request)
            all_versions = [member_view(item) for item in all_versions
                            if item.get("requested_by") == name]
            current = [member_view(item) for item in current
                       if item.get("requested_by") == name]
            executions, outcomes, notifications, reviews, acknowledgements = [], [], [], [], []
        else:
            authority(request, "recurring monitoring review")
        conn.close()
        return {"profiles": current, "version_history": all_versions,
                "cycle_executions": executions, "cycle_outcomes": outcomes,
                "review_notifications": notifications,
                "outcome_reviews": reviews,
                "notification_acknowledgements": acknowledgements,
                "monitoring_is_separate_from_tier": True,
                "automatic_charges": False, "automatic_disclosure": False}

    @app.post("/api/salintel/investigations/{investigation_id}/monitoring-selection")
    def select_monitoring(investigation_id: int, payload: MonitoringSelection, request: Request):
        require(request, "write")
        conn = db()
        try:
            row = investigation(conn, investigation_id, request)
            if not is_member(request):
                authority(request, "recurring monitoring request")
            if payload.recurring_monitoring == "Yes" and any(
                item.get("status") in ACTIVE_STATES for item in latest_profiles(conn, row["id"])
            ):
                raise HTTPException(409, "A monitoring profile is already awaiting approval or active")
            stamp = now()
            profile_key = "SIMON-" + uuid.uuid4().hex[:12].upper()
            value = {
                "record_type": "salintel_monitoring_profile",
                "profile_key": profile_key,
                "version_no": 1,
                "explicit_selection": payload.recurring_monitoring,
                "status": "Not Requested" if payload.recurring_monitoring == "No" else "Awaiting Salus Approval",
                **payload.model_dump(exclude={"recurring_monitoring"}),
                "baseline_investigation_id": row["id"],
                "baseline_record_key": row["record_key"],
                "baseline_tier_reference": int(row["completed_tier"] or row["authorized_tier"] or 0),
                "baseline_qualification_status": row["qualification_status"],
                "baseline_captured_at": stamp,
                "requested_by": actor(request), "requested_by_role": role(request),
                "requested_at": stamp, "approved_by": "", "approved_at": "",
                "tier_change_authorized": False, "investigation_reopen_authorized": False,
                "charge_created": False, "external_escalation_authorized": False,
                "member_release_authorized": False,
            }
            item_id = insert_version(conn, request, row, value)
            event_type = ("SALINTEL_MONITORING_NO_SELECTED" if payload.recurring_monitoring == "No"
                          else "SALINTEL_MONITORING_REQUESTED")
            event(conn, request, row, event_type,
                  "Explicit recurring monitoring selection recorded; no tier, cost, disclosure, or external authority changed.")
            audit(conn, request, event_type, item_id, profile_key)
            conn.commit()
            return {"id": item_id, **value}
        finally:
            conn.close()

    @app.post("/api/salintel/investigations/{investigation_id}/monitoring/{profile_key}/approve")
    def approve_monitoring(investigation_id: int, profile_key: str, payload: ApproveMonitoring,
                           request: Request):
        require(request, "decide")
        authority(request, "recurring monitoring approval")
        conn = db()
        try:
            row = investigation(conn, investigation_id, request)
            current = current_profile(conn, row["id"], profile_key)
            if current["status"] != "Awaiting Salus Approval" or current["explicit_selection"] != "Yes":
                raise HTTPException(409, "Only an affirmative request awaiting Salus approval can be activated")
            stamp = now()
            value = {**current, **payload.model_dump(), "record_type": "salintel_monitoring_profile",
                     "version_no": int(current["version_no"]) + 1, "status": "Active",
                     "approved_by": actor(request), "approved_by_role": role(request),
                     "approved_at": stamp, "lifecycle_action": "Approve and activate",
                     "lifecycle_reason": payload.approval_reason, "lifecycle_at": stamp,
                     "member_release_authorized": False, "charge_created": False,
                     "external_escalation_authorized": False, "tier_change_authorized": False,
                     "investigation_reopen_authorized": False}
            for transient in ("id", "item_key", "created_at"):
                value.pop(transient, None)
            item_id = insert_version(conn, request, row, value)
            event(conn, request, row, "SALINTEL_MONITORING_APPROVED_ACTIVATED", payload.approval_reason)
            audit(conn, request, "SALINTEL_MONITORING_APPROVED_ACTIVATED", item_id, profile_key)
            conn.commit()
            return {"id": item_id, **value}
        finally:
            conn.close()

    @app.post("/api/salintel/investigations/{investigation_id}/monitoring/{profile_key}/transition")
    def transition_monitoring(investigation_id: int, profile_key: str,
                              payload: MonitoringTransition, request: Request):
        require(request, "decide")
        authority(request, "recurring monitoring lifecycle")
        conn = db()
        try:
            row = investigation(conn, investigation_id, request)
            current = current_profile(conn, row["id"], profile_key)
            allowed = {("Active", "Pause"): "Paused", ("Paused", "Resume"): "Active",
                       ("Active", "End"): "Completed", ("Paused", "End"): "Completed",
                       ("Awaiting Salus Approval", "Cancel"): "Cancelled",
                       ("Active", "Cancel"): "Cancelled", ("Paused", "Cancel"): "Cancelled"}
            next_status = allowed.get((current["status"], payload.action))
            if not next_status:
                raise HTTPException(409, f"Cannot {payload.action.lower()} a {current['status']} profile")
            stamp = now()
            value = {**current, "record_type": "salintel_monitoring_profile",
                     "version_no": int(current["version_no"]) + 1, "status": next_status,
                     "lifecycle_action": payload.action, "lifecycle_reason": payload.reason,
                     "lifecycle_by": actor(request), "lifecycle_by_role": role(request),
                     "lifecycle_at": stamp, "member_release_authorized": False,
                     "charge_created": False, "external_escalation_authorized": False,
                     "tier_change_authorized": False, "investigation_reopen_authorized": False}
            for transient in ("id", "item_key", "created_at"):
                value.pop(transient, None)
            item_id = insert_version(conn, request, row, value)
            action = "SALINTEL_MONITORING_" + payload.action.upper()
            event(conn, request, row, action, payload.reason)
            audit(conn, request, action, item_id, profile_key)
            conn.commit()
            return {"id": item_id, **value}
        finally:
            conn.close()

    @app.post("/api/salintel/investigations/{investigation_id}/monitoring/{profile_key}/cycles")
    def execute_monitoring_cycle(investigation_id: int, profile_key: str,
                                 payload: ExecuteMonitoringCycle, request: Request):
        """Run the first no-cost source adapter inside the approved monitoring scope."""
        require(request, "write")
        authority(request, "recurring monitoring cycle execution")
        conn = db()
        try:
            row = investigation(conn, investigation_id, request)
            profile = current_profile(conn, row["id"], profile_key)
            if profile["status"] != "Active":
                raise HTTPException(409, "Monitoring research may run only for an Active profile")
            prior_executions = [item for item in records(
                conn, row["id"], "salintel_monitoring_cycle_execution"
            ) if item.get("profile_key") == profile_key]
            prior_outcomes = [item for item in records(
                conn, row["id"], "salintel_monitoring_cycle_outcome"
            ) if item.get("profile_key") == profile_key]
            open_ids = {item["id"] for item in prior_executions} - {
                int(item.get("execution_id", 0)) for item in prior_outcomes
            }
            if open_ids:
                raise HTTPException(409, "Record the open cycle outcome before starting another cycle")
            scheduled_for = (prior_outcomes[-1].get("next_research_date") if prior_outcomes
                             else profile.get("start_date", ""))
            if re.fullmatch(r"\d{4}-\d{2}-\d{2}", str(scheduled_for or "")):
                if now()[:10] < scheduled_for and not payload.execute_before_due:
                    raise HTTPException(
                        409, f"Next monitoring research is scheduled for {scheduled_for}; "
                        "an authorized early-cycle decision is required"
                    )
            terms = monitoring_terms(row, profile)
            candidates = conn.execute(
                "SELECT m.* FROM material_links l JOIN materials m ON m.id=l.material_id "
                "WHERE l.tenant_id=? AND l.target_type='salintel_investigation' "
                "AND l.target_id=? ORDER BY m.id",
                (row["tenant_id"], row["id"]),
            ).fetchall()
            matches = []
            for material in candidates:
                if material["processing_status"] in ("Quarantined", "Rejected"):
                    continue
                approved = {str(value).strip().lower()
                            for value in profile.get("approved_sources", []) if str(value).strip()}
                excluded = {str(value).strip().lower()
                            for value in profile.get("exclusions", []) if str(value).strip()}
                source_tags = {str(value).strip().lower()
                               for value in parsed(material["purpose_tags_json"], [])
                               if str(value).strip()}
                source_description = " ".join(str(material[key] or "") for key in (
                    "title", "source_origin", "source_locator", "description"
                )).lower()
                if approved and not any(
                    category in source_tags or category in source_description
                    for category in approved
                ):
                    continue
                if any(category in source_tags or category in source_description
                       for category in excluded):
                    continue
                try:
                    require_sensitivity(request, material["sensitivity"])
                except HTTPException:
                    continue
                searchable = " ".join(str(material[key] or "") for key in (
                    "title", "original_name", "source_origin", "source_locator", "description"
                )).lower()
                if terms and any(term in searchable for term in terms):
                    matches.append(material)
                if len(matches) == 50:
                    break
            stamp = now()
            value = {
                "record_type": "salintel_monitoring_cycle_execution", "schema_version": "1.0",
                "profile_key": profile_key, "profile_version": int(profile["version_no"]),
                "cycle_number": len(prior_executions) + 1,
                "status": "Research Completed — Outcome Required",
                "adapter": "Governed Material Search", "adapter_version": "1.0",
                "query_derived_by_server": True, "search_terms": terms,
                "approved_sources": profile.get("approved_sources", []),
                "source_exclusions": profile.get("exclusions", []),
                "baseline_record_key": profile.get("baseline_record_key"),
                "baseline_tier_reference": profile.get("baseline_tier_reference"),
                "baseline_captured_at": profile.get("baseline_captured_at"),
                "prior_execution_id": prior_executions[-1]["id"] if prior_executions else None,
                "prior_outcome": prior_outcomes[-1].get("outcome") if prior_outcomes else None,
                "matched_material_ids": [int(item["id"]) for item in matches],
                "source_access_records": [{
                    "material_id": int(item["id"]), "record_key": item["record_key"],
                    "title": item["title"], "source_origin": item["source_origin"],
                    "source_locator": f"salcapa://materials/{item['record_key']}",
                    "processing_status": item["processing_status"],
                    "provenance_status": item["provenance_status"], "outcome": "Accessed",
                    "source_bytes_reused_by_reference": True,
                } for item in matches],
                "no_match_statement": ("" if matches else
                    "The authorized adapter ran, but no linked governed material metadata matched. "
                    "This is not a finding that information does not exist."),
                "execution_authorization_reason": payload.reason,
                "scheduled_for": scheduled_for,
                "execution_basis": ("Salus-authorized early in-scope cycle"
                                    if payload.execute_before_due else "Approved cadence"),
                "triggered_by": actor(request), "triggered_by_role": role(request),
                "started_at": stamp, "completed_at": stamp,
                "external_network_accessed": False, "external_cost_incurred": False,
                "source_bytes_duplicated": False, "human_qualification_required": True,
                "tier_change_authorized": False, "investigation_reopen_authorized": False,
                "member_release_authorized": False, "external_escalation_authorized": False,
            }
            item_id = insert_record(
                conn, request, row, value, prefix="SIMC-", kind="Tool Execution",
                epistemic="Reported Information", title="Recurring monitoring cycle execution",
            )
            event(conn, request, row, "SALINTEL_MONITORING_CYCLE_EXECUTED",
                  f"profile={profile_key}; cycle={value['cycle_number']}; matches={len(matches)}")
            audit(conn, request, "SALINTEL_MONITORING_CYCLE_EXECUTED", item_id,
                  f"profile={profile_key}; matches={len(matches)}; external_network=false; cost=false")
            conn.commit()
            return {"id": item_id, **value}
        finally:
            conn.close()

    @app.post("/api/salintel/investigations/{investigation_id}/monitoring/{profile_key}/cycles/{execution_id}/outcome")
    def record_monitoring_outcome(investigation_id: int, profile_key: str, execution_id: int,
                                  payload: RecordMonitoringOutcome, request: Request):
        require(request, "write")
        authority(request, "recurring monitoring outcome submission")
        conn = db()
        try:
            row = investigation(conn, investigation_id, request)
            profile = current_profile(conn, row["id"], profile_key)
            cycle = execution(conn, row["id"], profile_key, execution_id)
            existing = [item for item in records(conn, row["id"], "salintel_monitoring_cycle_outcome")
                        if int(item.get("execution_id", 0)) == execution_id]
            if existing:
                raise HTTPException(409, "This monitoring cycle already has an outcome")
            allowed_materials = {int(value) for value in cycle.get("matched_material_ids", [])}
            evidence = {int(value) for value in payload.evidence_material_ids}
            finding_materials = {int(value) for finding in payload.findings
                                 for value in finding.material_ids}
            if not evidence.issubset(allowed_materials) or not finding_materials.issubset(allowed_materials):
                raise HTTPException(409, "Outcome evidence must come from material actually accessed in this cycle")
            if payload.outcome == "No Material Change" and not allowed_materials:
                raise HTTPException(409, "No Material Change requires completed research with accessed source material")
            if payload.outcome != "No Material Change" and not evidence:
                raise HTTPException(422, "A changed monitoring outcome requires supporting evidence")
            stamp = now()
            value = {
                "record_type": "salintel_monitoring_cycle_outcome", "schema_version": "1.0",
                "profile_key": profile_key, "profile_version": cycle["profile_version"],
                "execution_id": execution_id, "cycle_number": cycle["cycle_number"],
                **payload.model_dump(), "review_status": "Awaiting Salus Review",
                "baseline_record_key": cycle.get("baseline_record_key"),
                "baseline_captured_at": cycle.get("baseline_captured_at"),
                "prior_execution_id": cycle.get("prior_execution_id"),
                "prior_outcome": cycle.get("prior_outcome"),
                "recorded_by": actor(request), "recorded_by_role": role(request),
                "recorded_at": stamp,
                "next_research_date": next_research_date(profile.get("cadence", "Custom"), stamp),
                "human_qualification_required": True, "member_visible": False,
                "tier_change_authorized": False, "investigation_reopen_authorized": False,
                "charge_created": False, "member_release_authorized": False,
                "external_escalation_authorized": False,
            }
            epistemic = "Unknown" if payload.outcome == "No Material Change" else "Reported Information"
            item_id = insert_record(
                conn, request, row, value, prefix="SIMO-", kind="Finding", epistemic=epistemic,
                title=f"Monitoring outcome — {payload.outcome}",
            )
            urgent = payload.outcome in ("Material Change", "Escalation / Immediate Attention")
            notification = {
                "record_type": "salintel_monitoring_notification", "schema_version": "1.0",
                "profile_key": profile_key, "execution_id": execution_id,
                "outcome_id": item_id, "outcome": payload.outcome,
                "audience": "Authorized Salus personnel", "status": "Open",
                "priority": "Immediate" if urgent else "Review Queue",
                "policy": profile.get("review_requirements", "Salus human review required"),
                "member_notification_sent": False, "external_notification_sent": False,
                "created_at": stamp,
            }
            notification_id = insert_record(
                conn, request, row, notification, prefix="SIMN-", kind="Collection Requirement",
                epistemic="Unknown", title="Monitoring result requires Salus review",
            )
            event(conn, request, row, "SALINTEL_MONITORING_OUTCOME_RECORDED",
                  f"profile={profile_key}; cycle={cycle['cycle_number']}; outcome={payload.outcome}")
            audit(conn, request, "SALINTEL_MONITORING_OUTCOME_RECORDED", item_id,
                  f"profile={profile_key}; notification={notification_id}; review=required")
            conn.commit()
            return {"id": item_id, "notification_id": notification_id, **value}
        finally:
            conn.close()

    @app.post("/api/salintel/investigations/{investigation_id}/monitoring/{profile_key}/outcomes/{outcome_id}/review")
    def review_monitoring_outcome(investigation_id: int, profile_key: str, outcome_id: int,
                                  payload: ReviewMonitoringOutcome, request: Request):
        """Persist a separate Salus human decision; never rewrite Chat's outcome."""
        require(request, "decide")
        authority(request, "recurring monitoring human qualification")
        conn = db()
        try:
            row = investigation(conn, investigation_id, request)
            current_profile(conn, row["id"], profile_key)
            found = [item for item in records(
                conn, row["id"], "salintel_monitoring_cycle_outcome"
            ) if item["id"] == outcome_id and item.get("profile_key") == profile_key]
            if not found:
                raise HTTPException(404, "Monitoring outcome not found")
            existing = [item for item in records(
                conn, row["id"], "salintel_monitoring_outcome_review"
            ) if int(item.get("outcome_id", 0)) == outcome_id]
            if existing:
                raise HTTPException(409, "This monitoring outcome already has a human review")
            outcome = found[0]
            stamp = now()
            value = {
                "record_type": "salintel_monitoring_outcome_review", "schema_version": "1.0",
                "profile_key": profile_key, "profile_version": outcome["profile_version"],
                "execution_id": outcome["execution_id"], "outcome_id": outcome_id,
                "cycle_number": outcome["cycle_number"], "outcome": outcome["outcome"],
                "decision": payload.decision, "reason": payload.reason,
                "reviewed_by": actor(request), "reviewed_by_role": role(request),
                "reviewed_at": stamp, "human_qualified": payload.decision == "Qualified",
                "member_visible": False, "member_release_authorized": False,
                "member_notification_sent": False, "external_notification_sent": False,
                "tier_change_authorized": False, "investigation_reopen_authorized": False,
                "charge_created": False, "external_escalation_authorized": False,
                "source_outcome_preserved_unchanged": True,
            }
            item_id = insert_record(
                conn, request, row, value, prefix="SIMR-", kind="Finding",
                epistemic="Analyst Judgment", title=f"Monitoring human review — {payload.decision}",
            )
            event(conn, request, row, "SALINTEL_MONITORING_OUTCOME_REVIEWED",
                  f"profile={profile_key}; outcome_id={outcome_id}; decision={payload.decision}")
            audit(conn, request, "SALINTEL_MONITORING_OUTCOME_REVIEWED", item_id,
                  f"profile={profile_key}; outcome={outcome_id}; release=false; tier_change=false")
            conn.commit()
            return {"id": item_id, **value}
        finally:
            conn.close()

    @app.post("/api/salintel/investigations/{investigation_id}/monitoring/{profile_key}/notifications/{notification_id}/acknowledge")
    def acknowledge_monitoring_notification(
        investigation_id: int, profile_key: str, notification_id: int,
        payload: AcknowledgeMonitoringNotification, request: Request,
    ):
        """Acknowledge in-app receipt with a new immutable record."""
        require(request, "write")
        authority(request, "recurring monitoring notification acknowledgement")
        conn = db()
        try:
            row = investigation(conn, investigation_id, request)
            current_profile(conn, row["id"], profile_key)
            found = [item for item in records(
                conn, row["id"], "salintel_monitoring_notification"
            ) if item["id"] == notification_id and item.get("profile_key") == profile_key]
            if not found:
                raise HTTPException(404, "Monitoring notification not found")
            existing = [item for item in records(
                conn, row["id"], "salintel_monitoring_notification_acknowledgement"
            ) if int(item.get("notification_id", 0)) == notification_id]
            if existing:
                raise HTTPException(409, "This monitoring notification is already acknowledged")
            notice = found[0]
            stamp = now()
            value = {
                "record_type": "salintel_monitoring_notification_acknowledgement",
                "schema_version": "1.0", "profile_key": profile_key,
                "notification_id": notification_id, "outcome_id": notice["outcome_id"],
                "execution_id": notice["execution_id"], "status": "Acknowledged",
                "reason": payload.reason, "acknowledged_by": actor(request),
                "acknowledged_by_role": role(request), "acknowledged_at": stamp,
                "member_visible": False, "member_notification_sent": False,
                "external_notification_sent": False, "member_release_authorized": False,
                "charge_created": False, "external_escalation_authorized": False,
                "source_notification_preserved_unchanged": True,
            }
            item_id = insert_record(
                conn, request, row, value, prefix="SIMA-", kind="Collection Requirement",
                epistemic="Unknown", title="Monitoring notification acknowledgement",
            )
            event(conn, request, row, "SALINTEL_MONITORING_NOTIFICATION_ACKNOWLEDGED",
                  f"profile={profile_key}; notification_id={notification_id}")
            audit(conn, request, "SALINTEL_MONITORING_NOTIFICATION_ACKNOWLEDGED", item_id,
                  f"profile={profile_key}; notification={notification_id}; external=false")
            conn.commit()
            return {"id": item_id, **value}
        finally:
            conn.close()
