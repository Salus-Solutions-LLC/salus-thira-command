"""Governed recurring-monitoring profiles for every SalINTEL domain.

Monitoring is deliberately independent from investigation depth.  Every request,
approval, pause, resume, and end is an append-only profile version; none of these
actions reopens an investigation, changes tier, creates a charge, releases a result,
or authorizes an external party.
"""
from __future__ import annotations

import json
import uuid
from typing import Literal

from fastapi import HTTPException, Request
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

Selection = Literal["No", "Yes"]
Cadence = Literal["Daily", "Weekly", "Monthly", "Quarterly", "Custom"]
Commercial = Literal["Not Determined", "Included", "Bundled", "Separate Proposal", "Waived"]
Transition = Literal["Pause", "Resume", "End", "Cancel"]
ACTIVE_STATES = {"Awaiting Salus Approval", "Active", "Paused"}


class MonitoringSelection(BaseModel):
    model_config = ConfigDict(extra="forbid")
    recurring_monitoring: Selection = "No"
    purpose: str = Field(default="", max_length=4000)
    requested_scope: str = Field(default="", max_length=8000)
    requested_cadence: Cadence | None = None
    requested_start_date: str = Field(default="", max_length=40)
    requested_end_date: str = Field(default="", max_length=40)
    requested_renewal_date: str = Field(default="", max_length=40)
    source_categories: list[str] = Field(default_factory=list, max_length=100)
    exclusions: list[str] = Field(default_factory=list, max_length=100)
    questions: list[str] = Field(default_factory=list, max_length=200)
    known_unknowns: list[str] = Field(default_factory=list, max_length=200)
    indicators: list[str] = Field(default_factory=list, max_length=200)
    watch_terms: list[str] = Field(default_factory=list, max_length=200)
    entities: list[str] = Field(default_factory=list, max_length=200)
    relationships: list[str] = Field(default_factory=list, max_length=200)
    dependencies: list[str] = Field(default_factory=list, max_length=200)
    geographic_bounds: str = Field(default="", max_length=4000)
    jurisdiction_bounds: str = Field(default="", max_length=4000)
    language_bounds: str = Field(default="", max_length=1000)
    change_thresholds: str = Field(default="", max_length=8000)
    escalation_criteria: str = Field(default="", max_length=8000)
    partner_support_requested: bool = False
    commercial_preference: Commercial = "Not Determined"

    @field_validator("recurring_monitoring", mode="before")
    @classmethod
    def null_is_no(cls, value):
        return "No" if value is None or value == "" else value

    @field_validator(
        "purpose", "requested_scope", "requested_start_date", "requested_end_date",
        "requested_renewal_date", "geographic_bounds", "jurisdiction_bounds",
        "language_bounds", "change_thresholds", "escalation_criteria",
    )
    @classmethod
    def clean_text(cls, value: str) -> str:
        return value.strip()

    @field_validator(
        "source_categories", "exclusions", "questions", "known_unknowns",
        "indicators", "watch_terms", "entities", "relationships", "dependencies",
    )
    @classmethod
    def clean_list(cls, value: list[str]) -> list[str]:
        result = list(dict.fromkeys(str(item).strip() for item in value if str(item).strip()))
        if any(len(item) > 1000 for item in result):
            raise ValueError("Monitoring list entries may not exceed 1000 characters")
        return result

    @model_validator(mode="after")
    def require_affirmative_scope(self):
        if self.recurring_monitoring == "Yes":
            if not self.purpose or not self.requested_scope or self.requested_cadence is None:
                raise ValueError("A Yes selection requires purpose, requested scope, and cadence")
        return self


class ApproveMonitoring(BaseModel):
    model_config = ConfigDict(extra="forbid")
    approved_scope: str = Field(min_length=1, max_length=8000)
    cadence: Cadence
    cadence_detail: str = Field(default="", max_length=1000)
    start_date: str = Field(min_length=1, max_length=40)
    end_date: str = Field(default="", max_length=40)
    renewal_date: str = Field(default="", max_length=40)
    approved_sources: list[str] = Field(min_length=1, max_length=100)
    exclusions: list[str] = Field(default_factory=list, max_length=100)
    questions: list[str] = Field(default_factory=list, max_length=200)
    known_unknowns: list[str] = Field(default_factory=list, max_length=200)
    indicators: list[str] = Field(default_factory=list, max_length=200)
    watch_terms: list[str] = Field(default_factory=list, max_length=200)
    entities: list[str] = Field(default_factory=list, max_length=200)
    relationships: list[str] = Field(default_factory=list, max_length=200)
    dependencies: list[str] = Field(default_factory=list, max_length=200)
    geographic_bounds: str = Field(default="", max_length=4000)
    jurisdiction_bounds: str = Field(default="", max_length=4000)
    language_bounds: str = Field(default="", max_length=1000)
    change_thresholds: str = Field(min_length=1, max_length=8000)
    escalation_criteria: str = Field(min_length=1, max_length=8000)
    review_requirements: str = Field(min_length=1, max_length=4000)
    member_notification_policy: str = Field(min_length=1, max_length=4000)
    member_release_permitted: bool = False
    global_partner_eligible: bool = False
    commercial_treatment: Commercial
    commercial_reference: str = Field(default="", max_length=500)
    approval_reason: str = Field(min_length=1, max_length=4000)

    @field_validator(
        "approved_scope", "cadence_detail", "start_date", "end_date", "renewal_date",
        "geographic_bounds", "jurisdiction_bounds", "language_bounds", "change_thresholds",
        "escalation_criteria", "review_requirements", "member_notification_policy",
        "commercial_reference", "approval_reason",
    )
    @classmethod
    def clean_text(cls, value: str) -> str:
        result = value.strip()
        return result

    @field_validator(
        "approved_sources", "exclusions", "questions", "known_unknowns", "indicators",
        "watch_terms", "entities", "relationships", "dependencies",
    )
    @classmethod
    def clean_list(cls, value: list[str]) -> list[str]:
        result = list(dict.fromkeys(str(item).strip() for item in value if str(item).strip()))
        if any(len(item) > 1000 for item in result):
            raise ValueError("Monitoring list entries may not exceed 1000 characters")
        return result


class MonitoringTransition(BaseModel):
    model_config = ConfigDict(extra="forbid")
    action: Transition
    reason: str = Field(min_length=1, max_length=4000)

    @field_validator("reason")
    @classmethod
    def clean_reason(cls, value: str) -> str:
        result = value.strip()
        if not result:
            raise ValueError("A reason is required")
        return result


def register_salintel_monitoring(app, core: dict) -> None:
    db, now = core["db"], core["now"]
    actor, role, tenant_id = core["actor"], core["role"], core["tenant_id"]
    require = core["require"]
    authority = core["require_salus_component_authority"]
    require_sensitivity = core["require_sensitivity"]
    is_member = core["protected_member_request"]
    security_event = core["security_event"]

    def canonical(value):
        return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str)

    def parsed(value, fallback):
        try:
            result = json.loads(value)
            return result
        except (TypeError, ValueError, json.JSONDecodeError):
            return fallback

    def item_detail(item):
        value = parsed(item["detail"], {})
        return value if isinstance(value, dict) else {}

    def investigation(conn, investigation_id: int, request: Request):
        row = conn.execute(
            "SELECT * FROM salintel_investigations WHERE id=?", (investigation_id,)
        ).fetchone()
        if not row:
            raise HTTPException(404, "SalINTEL investigation not found")
        if int(row["tenant_id"]) != tenant_id(request):
            security_event(request, "SALINTEL_MONITORING_TENANT_BOUNDARY_VIOLATION", "High",
                           f"investigation_id={investigation_id}")
            raise HTTPException(403, "Tenant boundary violation")
        require_sensitivity(request, row["sensitivity"])
        if is_member(request) and row["disclosure_status"] != "Approved for Tenant":
            raise HTTPException(403, "Investigation is not approved for Protected Member access")
        return row

    def versions(conn, investigation_id: int):
        result = []
        for item in conn.execute(
            "SELECT * FROM salintel_investigation_items WHERE investigation_id=? ORDER BY id",
            (investigation_id,),
        ):
            value = item_detail(item)
            if value.get("record_type") == "salintel_monitoring_profile":
                result.append({"id": item["id"], "item_key": item["item_key"],
                               "created_at": item["created_at"], **value})
        return result

    def latest_profiles(conn, investigation_id: int):
        latest = {}
        for value in versions(conn, investigation_id):
            key = value["profile_key"]
            if key not in latest or int(value["version_no"]) > int(latest[key]["version_no"]):
                latest[key] = value
        return list(latest.values())

    def current_profile(conn, investigation_id: int, profile_key: str):
        found = [value for value in versions(conn, investigation_id)
                 if value["profile_key"] == profile_key]
        if not found:
            raise HTTPException(404, "Monitoring profile not found")
        return max(found, key=lambda value: int(value["version_no"]))

    def insert_version(conn, request: Request, row, value: dict):
        stamp = now()
        item_key = "SIMP-" + uuid.uuid4().hex[:12].upper()
        conn.execute(
            "INSERT INTO salintel_investigation_items(tenant_id,investigation_id,item_key,"
            "item_kind,epistemic_state,title,detail,source_reliability,information_confidence,"
            "source_material_id,member_visible,created_by,created_at,updated_at) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (row["tenant_id"], row["id"], item_key, "Collection Requirement", "Unknown",
             "Recurring monitoring profile", canonical(value), "Not Assessed", "Not Assessed",
             None, 0, actor(request), stamp, stamp),
        )
        return int(conn.execute(
            "SELECT id FROM salintel_investigation_items WHERE item_key=?", (item_key,)
        ).fetchone()["id"])

    def event(conn, request: Request, row, event_type: str, reason: str):
        version = int(conn.execute(
            "SELECT COUNT(*) c FROM salintel_investigation_events WHERE investigation_id=?",
            (row["id"],),
        ).fetchone()["c"]) + 1
        snapshot = conn.execute(
            "SELECT * FROM salintel_investigations WHERE id=?", (row["id"],)
        ).fetchone()
        conn.execute(
            "INSERT INTO salintel_investigation_events(tenant_id,investigation_id,version_no,"
            "event_type,reason,snapshot_json,changed_by,changed_by_role,created_at) "
            "VALUES(?,?,?,?,?,?,?,?,?)",
            (row["tenant_id"], row["id"], version, event_type, reason[:4000],
             canonical(dict(snapshot)), actor(request), role(request), now()),
        )

    def audit(conn, request: Request, action: str, entity_id: int, detail: str):
        conn.execute(
            "INSERT INTO audit_log(ts,user_name,action,entity_type,entity_id,detail,tenant_id) "
            "VALUES(?,?,?,?,?,?,?)",
            (now(), actor(request), action, "salintel_monitoring_profile", entity_id,
             detail[:2000], tenant_id(request)),
        )

    def member_view(value):
        allowed = {
            "profile_key", "version_no", "explicit_selection", "status", "purpose",
            "requested_scope", "requested_cadence", "requested_start_date",
            "requested_end_date", "requested_renewal_date", "baseline_tier_reference",
            "requested_by", "requested_at", "approved_scope", "cadence", "cadence_detail",
            "start_date", "end_date", "renewal_date", "member_notification_policy",
            "member_release_permitted", "approved_at", "lifecycle_action", "lifecycle_at",
            "created_at",
        }
        return {key: value[key] for key in allowed if key in value}

    @app.get("/api/salintel/investigations/{investigation_id}/monitoring")
    def list_monitoring(investigation_id: int, request: Request):
        require(request, "read")
        conn = db()
        row = investigation(conn, investigation_id, request)
        all_versions = versions(conn, row["id"])
        current = latest_profiles(conn, row["id"])
        if is_member(request):
            name = actor(request)
            all_versions = [member_view(item) for item in all_versions
                            if item.get("requested_by") == name]
            current = [member_view(item) for item in current
                       if item.get("requested_by") == name]
        else:
            authority(request, "recurring monitoring review")
        conn.close()
        return {"profiles": current, "version_history": all_versions,
                "monitoring_is_separate_from_tier": True,
                "automatic_charges": False, "automatic_disclosure": False}

    @app.post("/api/salintel/investigations/{investigation_id}/monitoring-selection")
    def select_monitoring(investigation_id: int, payload: MonitoringSelection, request: Request):
        require(request, "write")
        conn = db()
        try:
            row = investigation(conn, investigation_id, request)
            if not is_member(request):
                authority(request, "recurring monitoring request")
            if payload.recurring_monitoring == "Yes" and any(
                item.get("status") in ACTIVE_STATES for item in latest_profiles(conn, row["id"])
            ):
                raise HTTPException(409, "A monitoring profile is already awaiting approval or active")
            stamp = now()
            profile_key = "SIMON-" + uuid.uuid4().hex[:12].upper()
            value = {
                "record_type": "salintel_monitoring_profile",
                "profile_key": profile_key,
                "version_no": 1,
                "explicit_selection": payload.recurring_monitoring,
                "status": "Not Requested" if payload.recurring_monitoring == "No" else "Awaiting Salus Approval",
                **payload.model_dump(exclude={"recurring_monitoring"}),
                "baseline_investigation_id": row["id"],
                "baseline_record_key": row["record_key"],
                "baseline_tier_reference": int(row["completed_tier"] or row["authorized_tier"] or 0),
                "baseline_qualification_status": row["qualification_status"],
                "baseline_captured_at": stamp,
                "requested_by": actor(request), "requested_by_role": role(request),
                "requested_at": stamp, "approved_by": "", "approved_at": "",
                "tier_change_authorized": False, "investigation_reopen_authorized": False,
                "charge_created": False, "external_escalation_authorized": False,
                "member_release_authorized": False,
            }
            item_id = insert_version(conn, request, row, value)
            event_type = ("SALINTEL_MONITORING_NO_SELECTED" if payload.recurring_monitoring == "No"
                          else "SALINTEL_MONITORING_REQUESTED")
            event(conn, request, row, event_type,
                  "Explicit recurring monitoring selection recorded; no tier, cost, disclosure, or external authority changed.")
            audit(conn, request, event_type, item_id, profile_key)
            conn.commit()
            return {"id": item_id, **value}
        finally:
            conn.close()

    @app.post("/api/salintel/investigations/{investigation_id}/monitoring/{profile_key}/approve")
    def approve_monitoring(investigation_id: int, profile_key: str, payload: ApproveMonitoring,
                           request: Request):
        require(request, "decide")
        authority(request, "recurring monitoring approval")
        conn = db()
        try:
            row = investigation(conn, investigation_id, request)
            current = current_profile(conn, row["id"], profile_key)
            if current["status"] != "Awaiting Salus Approval" or current["explicit_selection"] != "Yes":
                raise HTTPException(409, "Only an affirmative request awaiting Salus approval can be activated")
            stamp = now()
            value = {**current, **payload.model_dump(), "record_type": "salintel_monitoring_profile",
                     "version_no": int(current["version_no"]) + 1, "status": "Active",
                     "approved_by": actor(request), "approved_by_role": role(request),
                     "approved_at": stamp, "lifecycle_action": "Approve and activate",
                     "lifecycle_reason": payload.approval_reason, "lifecycle_at": stamp,
                     "member_release_authorized": False, "charge_created": False,
                     "external_escalation_authorized": False, "tier_change_authorized": False,
                     "investigation_reopen_authorized": False}
            for transient in ("id", "item_key", "created_at"):
                value.pop(transient, None)
            item_id = insert_version(conn, request, row, value)
            event(conn, request, row, "SALINTEL_MONITORING_APPROVED_ACTIVATED", payload.approval_reason)
            audit(conn, request, "SALINTEL_MONITORING_APPROVED_ACTIVATED", item_id, profile_key)
            conn.commit()
            return {"id": item_id, **value}
        finally:
            conn.close()

    @app.post("/api/salintel/investigations/{investigation_id}/monitoring/{profile_key}/transition")
    def transition_monitoring(investigation_id: int, profile_key: str,
                              payload: MonitoringTransition, request: Request):
        require(request, "decide")
        authority(request, "recurring monitoring lifecycle")
        conn = db()
        try:
            row = investigation(conn, investigation_id, request)
            current = current_profile(conn, row["id"], profile_key)
            allowed = {("Active", "Pause"): "Paused", ("Paused", "Resume"): "Active",
                       ("Active", "End"): "Completed", ("Paused", "End"): "Completed",
                       ("Awaiting Salus Approval", "Cancel"): "Cancelled",
                       ("Active", "Cancel"): "Cancelled", ("Paused", "Cancel"): "Cancelled"}
            next_status = allowed.get((current["status"], payload.action))
            if not next_status:
                raise HTTPException(409, f"Cannot {payload.action.lower()} a {current['status']} profile")
            stamp = now()
            value = {**current, "record_type": "salintel_monitoring_profile",
                     "version_no": int(current["version_no"]) + 1, "status": next_status,
                     "lifecycle_action": payload.action, "lifecycle_reason": payload.reason,
                     "lifecycle_by": actor(request), "lifecycle_by_role": role(request),
                     "lifecycle_at": stamp, "member_release_authorized": False,
                     "charge_created": False, "external_escalation_authorized": False,
                     "tier_change_authorized": False, "investigation_reopen_authorized": False}
            for transient in ("id", "item_key", "created_at"):
                value.pop(transient, None)
            item_id = insert_version(conn, request, row, value)
            action = "SALINTEL_MONITORING_" + payload.action.upper()
            event(conn, request, row, action, payload.reason)
            audit(conn, request, action, item_id, profile_key)
            conn.commit()
            return {"id": item_id, **value}
        finally:
            conn.close()
