#!/usr/bin/env python3
"""Acceptance checks for governed, versioned SalINTEL recurring monitoring."""
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORKSPACE = tempfile.TemporaryDirectory()
os.environ.setdefault("SALUS_DB_BACKEND", "sqlite")
os.environ.setdefault("SALUS_DB_PATH", str(Path(WORKSPACE.name) / "monitoring.db"))
os.environ.setdefault("SALUS_BACKUP_DIR", str(Path(WORKSPACE.name) / "backups"))
os.environ.setdefault("SALUS_LOCAL_STORAGE_DIR", str(Path(WORKSPACE.name) / "attachments"))
os.environ.setdefault("SALUS_AUTH_MODE", "prototype")
os.environ.setdefault("SALUS_SEED_DEMO", "1")
sys.path.insert(0, str(ROOT))

from fastapi.testclient import TestClient
import salcapa_runtime
from portable_backup import collect_tenant_records, replace_tenant_records, validate_records


def main():
    client = TestClient(salcapa_runtime.app)
    analyst = {"X-Salus-Tenant": "1", "X-Salus-Role": "Assessment Director",
               "X-Salus-User": "Monitoring Supervisor",
               "X-Salus-Clearance": "Highly Sensitive"}
    member = {"X-Salus-Tenant": "1", "X-Salus-Role": "Contributor",
              "X-Salus-User": "Protected Member Requester"}
    other = {"X-Salus-Tenant": "2", "X-Salus-Role": "Assessment Director",
             "X-Salus-User": "Other Tenant", "X-Salus-Clearance": "Highly Sensitive"}

    created = client.post("/api/salintel/investigations", headers=analyst, json={
        "domain_key": "organizations", "title": "SYNTHETIC monitoring baseline",
        "subject_reference": "SYNTHETIC-ORG-WATCH-001",
        "purpose": "Lawful synthetic recurring-monitoring acceptance.",
        "requested_tier": 1, "sensitivity": "Sensitive"})
    assert created.status_code == 200, created.text
    record_id = created.json()["id"]

    default_no = client.post(
        f"/api/salintel/investigations/{record_id}/monitoring-selection",
        headers=analyst, json={})
    assert default_no.status_code == 200, default_no.text
    assert default_no.json()["explicit_selection"] == "No"
    assert default_no.json()["status"] == "Not Requested"
    assert default_no.json()["charge_created"] is False

    forged = client.post(
        f"/api/salintel/investigations/{record_id}/monitoring-selection",
        headers=analyst, json={"recurring_monitoring": "Yes", "purpose": "Watch",
        "requested_scope": "Approved public-source changes.",
        "requested_cadence": "Weekly", "status": "Active", "approved_by": "Client"})
    assert forged.status_code == 422
    incomplete = client.post(
        f"/api/salintel/investigations/{record_id}/monitoring-selection",
        headers=analyst, json={"recurring_monitoring": "Yes"})
    assert incomplete.status_code == 422
    assert client.get(f"/api/salintel/investigations/{record_id}/monitoring",
                      headers=member).status_code == 403
    assert client.get(f"/api/salintel/investigations/{record_id}/monitoring",
                      headers=other).status_code == 403

    # Establish a disclosed completed baseline only for Protected Member request testing.
    conn = salcapa_runtime.core.db()
    conn.execute("UPDATE salintel_investigations SET status='Tier Complete',"
                 "qualification_status='Qualified',authorized_tier=1,completed_tier=1,"
                 "disclosure_status='Approved for Tenant' WHERE id=?", (record_id,))
    conn.commit(); conn.close()

    request = client.post(
        f"/api/salintel/investigations/{record_id}/monitoring-selection",
        headers=member, json={"recurring_monitoring": "Yes",
        "purpose": "Watch material changes affecting protected operations.",
        "requested_scope": "Documented organizational status and service changes.",
        "requested_cadence": "Weekly", "requested_start_date": "2026-09-08",
        "source_categories": ["lawful public sources"],
        "exclusions": ["personal financial dossiers"],
        "questions": ["Has ownership or operational capacity materially changed?"],
        "known_unknowns": ["Unpublished continuity arrangements"],
        "indicators": ["regulatory filing", "service interruption"],
        "watch_terms": ["SYNTHETIC ORG"], "entities": ["SYNTHETIC ORG"],
        "relationships": ["supplies protected operation"],
        "dependencies": ["essential service"],
        "geographic_bounds": "United States", "jurisdiction_bounds": "Federal and state",
        "language_bounds": "English", "change_thresholds": "Verified control or service change.",
        "escalation_criteria": "Credible immediate continuity impact.",
        "partner_support_requested": False, "commercial_preference": "Not Determined"})
    assert request.status_code == 200, request.text
    profile_key = request.json()["profile_key"]
    assert request.json()["status"] == "Awaiting Salus Approval"
    assert request.json()["baseline_tier_reference"] == 1
    assert request.json()["tier_change_authorized"] is False
    assert request.json()["member_release_authorized"] is False

    duplicate = client.post(
        f"/api/salintel/investigations/{record_id}/monitoring-selection",
        headers=analyst, json={"recurring_monitoring": "Yes", "purpose": "Duplicate",
        "requested_scope": "Duplicate watch.", "requested_cadence": "Monthly"})
    assert duplicate.status_code == 409
    approval_path = f"/api/salintel/investigations/{record_id}/monitoring/{profile_key}/approve"
    approval = {"approved_scope": "Bounded documented organizational and service changes.",
        "cadence": "Weekly", "cadence_detail": "Each Tuesday after 09:00 UTC",
        "start_date": "2026-09-08", "end_date": "2027-09-08",
        "renewal_date": "2027-08-08", "approved_sources": ["lawful public sources"],
        "exclusions": ["personal financial dossiers"],
        "questions": ["Has ownership or capacity materially changed?"],
        "known_unknowns": ["Unpublished continuity arrangements"],
        "indicators": ["regulatory filing", "service interruption"],
        "watch_terms": ["SYNTHETIC ORG"], "entities": ["SYNTHETIC ORG"],
        "relationships": ["supplies protected operation"], "dependencies": ["essential service"],
        "geographic_bounds": "United States", "jurisdiction_bounds": "Federal and state",
        "language_bounds": "English", "change_thresholds": "Verified control or service change.",
        "escalation_criteria": "Credible immediate continuity impact.",
        "review_requirements": "Authorized Salus human review every cycle.",
        "member_notification_policy": "Explicit Salus release decision before member notice.",
        "member_release_permitted": False, "global_partner_eligible": False,
        "commercial_treatment": "Included", "commercial_reference": "SYNTHETIC-TERMS",
        "approval_reason": "Approved bounded no-cost synthetic watch."}
    assert client.post(approval_path, headers=member, json=approval).status_code == 403
    approved = client.post(approval_path, headers=analyst, json=approval)
    assert approved.status_code == 200, approved.text
    assert approved.json()["status"] == "Active" and approved.json()["version_no"] == 2
    assert approved.json()["charge_created"] is False
    assert approved.json()["external_escalation_authorized"] is False
    assert client.post(approval_path, headers=analyst, json=approval).status_code == 409

    path = f"/api/salintel/investigations/{record_id}/monitoring/{profile_key}/transition"
    paused = client.post(path, headers=analyst, json={"action": "Pause", "reason": "Review cadence."})
    assert paused.status_code == 200 and paused.json()["status"] == "Paused"
    resumed = client.post(path, headers=analyst, json={"action": "Resume", "reason": "Review complete."})
    assert resumed.status_code == 200 and resumed.json()["status"] == "Active"
    ended = client.post(path, headers=analyst, json={"action": "End", "reason": "Approved term ended."})
    assert ended.status_code == 200 and ended.json()["status"] == "Completed"
    assert client.post(path, headers=analyst, json={"action": "Resume", "reason": "Forgery."}).status_code == 409

    view = client.get(f"/api/salintel/investigations/{record_id}/monitoring", headers=analyst)
    assert view.status_code == 200, view.text
    data = view.json()
    assert len(next(x for x in data["profiles"] if x["profile_key"] == profile_key)) > 10
    history = [x for x in data["version_history"] if x["profile_key"] == profile_key]
    assert [x["version_no"] for x in history] == [1, 2, 3, 4, 5]
    assert data["automatic_charges"] is False and data["automatic_disclosure"] is False

    conn = salcapa_runtime.core.db()
    record = conn.execute("SELECT * FROM salintel_investigations WHERE id=?", (record_id,)).fetchone()
    assert record["authorized_tier"] == 1 and record["completed_tier"] == 1
    records = collect_tenant_records(conn, 1)
    validate_records(records)
    count = len([x for x in records["salintel_investigation_items"]
                 if x["investigation_id"] == record_id and "salintel_monitoring_profile" in x["detail"]])
    assert count == 6
    replace_tenant_records(conn, 1, records)
    restored = conn.execute("SELECT COUNT(*) c FROM salintel_investigation_items WHERE investigation_id=?",
                            (record_id,)).fetchone()["c"]
    assert restored >= 6
    conn.close()
    print("SALINTEL_MONITORING_SMOKE_PASS")


if __name__ == "__main__":
    main()
